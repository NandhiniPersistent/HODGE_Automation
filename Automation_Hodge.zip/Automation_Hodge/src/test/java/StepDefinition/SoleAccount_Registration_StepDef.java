package StepDefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import PageObjects.NominatedBankDetails;
import PageObjects.ReviewInformation;
import PageObjects.UpdateNominationDetail;
import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class SoleAccount_Registration_StepDef 
{ 
	 private static WebDriver driver;
	 
	 public NominatedBankDetails NominatedPage;
	 ReviewInformation  reviewinfo;
	 UpdateNominationDetail updatenominateDetail;

	    @Given("^user navigates to Nominated Bank for Sole Account$")
		public void user_navigates_to_nominated_bank_for_sole_account() 
		{
			WebDriverManager.edgedriver().setup();
			driver= new EdgeDriver();
			NominatedPage =new NominatedBankDetails(driver);
			driver.get("https://d3t331mvgv7oxd.cloudfront.net/");
			
		}
	
	    @When("^User can view Application Process page with Nominated bank details$")
		public void user_can_view_application_process_page_with_nominated_bank_details() 
		{}
	
	    @Then("^User enters account holder name as \"([^\"]*)\"$")
	    public void user_enters_account_holder_name_as(String Name)
		{
	    	NominatedPage.enterAccHolderName(Name);
			
		}
		
		
	    @Then("^User enters first digit for sort code as \"([^\"]*)\" $")
	    public void user_enters_first_digit_for_sort_code_as(String sortCode1)
	    {
	    	
	    	NominatedPage.enterSortCode1(sortCode1);
	    }
	
	    @Then("^User enters second digit for sort code as \"([^\"]*)\"$")
	    public void user_enters_second_digit_for_sort_code_as(String sortCode2) 
	    {
	    	NominatedPage.enterSortCode2(sortCode2);
	  
	    }
	
	    @Then("^User enters third digit for sort code as \"([^\"]*)\" $")
	    public void user_enters_third_digit_for_sort_code_as(String sortCode3)
	    {
	    	NominatedPage.enterSortCode3(sortCode3);
	    }
	    
		@Then("^User enters Account number as \"([^\"]*)\"$")
		public void user_enters_account_number_as(String accountNumber) 
		{
			NominatedPage.enterAccNumber(accountNumber);
		    
		}
	
		@Then("^User enters Account number as \"([^\"]*)\"$")
		public void reenters_account_number_as(String reAccountNumber) 
		{
			NominatedPage.enterReenterAccNumber(reAccountNumber);
		}
	
		@Then("^Source of funds dropdown should be displayed$")
		public void source_of_funds_dropdown_should_be_displayed() 
		{}
	
		@Then("^User selects Source of funds from dropdown as \"([^\"]*)\"$")
		public void user_selects_source_of_funds_from_dropdown_as(String sourceFund)
		{
			NominatedPage.enterSourcFund(sourceFund);
			
		}
	
		@Then("^User enters Indicative Deposit Amount as \"([^\"]*)\"$")
		public void user_enters_indicative_deposit_amount_as(String indicativeDepositAmount) 
		{
			NominatedPage.enterIndicativeDepositAmount(indicativeDepositAmount);
		}
	
		@Then("^Interest Payment Preference from toggle button as New Hodge a/c or Nominated a/c$")
	     public void interest_payment_preference_from_toggle_button_as_new_hodge_ac_or_nominated_ac() 
		  {
	
		  }
		
	
		@Then("^User selects toggle button as \"([^\"]*)\" from Interest Payment Preference$")
		public void user_selects_toggle_button_as_from_interest_payment_preference(String interestPaymentPreference) 
		{
			if(interestPaymentPreference.equals("New Hodge a/c"))
			{
				NominatedPage.ClickNewHodgeAccount();
			}
		    if(interestPaymentPreference.equals("Nominated a/c"))
		    {
		    	NominatedPage.ClickNominatedAccount();
			}
		 }
	
		@Then("^Click on Save & Proceed button$")
		public void click_on_save_proceed_button() 
		{
			NominatedPage.ClickSaveProceedBtn();
		 
		}
	
	   @Given("^User can view review information page with the title \"([^\"]*)\"$")
	   public void user_can_view_review_information_page_with_the_title(String expTitle) 
	   {
		   reviewinfo =new ReviewInformation(driver);
		   
		   String actualTitle = driver.getTitle();
			
			if(actualTitle.equals(expTitle))
			{
				Assert.assertTrue(true);
			}
			else 
			{
				Assert.assertTrue(false);
			}
	   }
	
	   
	
	   @When("^User clicks on personal details $")
	   public void user_clicks_on_personal_details() 
	   {
		   reviewinfo.clickPersonalDetails();
	   }
	
	   @When("^User can view all the entered personal details and additional information$")
	   public void user_can_view_all_the_entered_personal_details_and_additional_information()
	   {
	
		   String[] expectedPersonalInfo={"Mrs","Lavina", "-","Demo", "06-06-1999", "AB-12-46-98-B","+44 7709 175684","zaidon.khylin@aladeen.org",
				   "British","302","G/M, 11 Kelburn Court Largs","KA30 8HN","No","SMS,Email","Email,Telephone"}; 
			
		   if(reviewinfo.getTxtTitle().equals(expectedPersonalInfo[0]))
		   {
			   Assert.assertTrue(true);
		   }
	
		   if(reviewinfo.getTxtFirstName().equals(expectedPersonalInfo[1]))
		   {
			   Assert.assertTrue(true);
		   }
			  
		   if(reviewinfo.getTxtMiddleName().equals(expectedPersonalInfo[2]))
		   {
			   Assert.assertTrue(true);
		   }
			
		   if(reviewinfo.getTxtLastName().equals(expectedPersonalInfo[3]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtDOB().equals(expectedPersonalInfo[4]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtNIN().equals(expectedPersonalInfo[5]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtMobNo().equals(expectedPersonalInfo[6]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtEmailAddress().equals(expectedPersonalInfo[7]))
		   {
			   Assert.assertTrue(true);
		   }
		   if(reviewinfo.getTxtNationality().equals(expectedPersonalInfo[8]))
		   {
			   Assert.assertTrue(true);
		   }
		   if(reviewinfo.getTxtHomeNo().equals(expectedPersonalInfo[9]))
		   {
			   Assert.assertTrue(true);
		   }
		   if(reviewinfo.getTxtResidentialAddress().equals(expectedPersonalInfo[10]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtPostalCode().equals(expectedPersonalInfo[11]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtUSResident().equals(expectedPersonalInfo[12]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtMarketingPreference().equals(expectedPersonalInfo[13]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtContactPreference().equals(expectedPersonalInfo[14]))
		   {
			   Assert.assertTrue(true);
		   }
	 }
	
	   @When("^User clicks on nominated bank details$")
	   public void user_clicks_on_nominated_bank_details()
	   {
		   reviewinfo.clickNominatedDetails();
	   }
	
	  @When("^User can view all the entered nominated bank details$")
	  public void user_can_view_all_the_entered_nominated_bank_details()
	  {
		   String[] expectedNominatedInfo={"levis demo","07-01-16","99125678","Inheritance","£1000","New Hodge a/c"}; 
		
	
		   if(reviewinfo.getTxtAccountHolderName().equals(expectedNominatedInfo[0]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtSortCode().equals(expectedNominatedInfo[1]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.gettxtAccountNumber().equals(expectedNominatedInfo[2]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtSourcOfFund().equals(expectedNominatedInfo[3]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtIndicativeDepositAmount().equals(expectedNominatedInfo[4]))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(reviewinfo.getTxtInterestPaymentPreference().equals(expectedNominatedInfo[5]))
		   {
			   Assert.assertTrue(true);
		   }
		      
		}
	
	  @When("^User clicks on checkbox provided for accepting the given consents$")
	  public void user_clicks_on_checkbox_provided_for_accepting_the_given_consents()
	  {
		  reviewinfo.clickFirstTerm();
		  reviewinfo.clickSecondTerm();
		  reviewinfo.clickThirdTerm();
		  reviewinfo.clickFourthTerm();
	  }
	
	  @When("^User clicks on submit button$")
	  public void user_clicks_on_submit_button() 
	  {
		  reviewinfo.clickSubmitBtn();
	
	  }
	
	  @Then("^Application submitted successfully $")
	  public void application_submitted_successfully() 
	  {}
 
	  
	@Given("^User register with Sole Onboarding Successfully and view review information page$")
	  public void user_register_with_sole_onboarding_successfully_and_view_review_information_page() 
	  {
		updatenominateDetail=new UpdateNominationDetail(driver);
	  }
	  
	@When("^User clicks on nominated bank details to view enterd nominated bank information$")
	public void user_clicks_on_nominated_bank_details_to_view_enterd_nominated_bank_information()
	{
		updatenominateDetail.clickNominatedAccount();
	    
	}
	
	@When("^User click on edit button to  update nominated bank details$")
	public void user_click_on_edit_button_to_update_nominated_bank_details() 
	{
		updatenominateDetail.clickNominatedDetailEditBtn();
	}
	
	@When("^User updates account holder \"([^\"]*)\" as Name$")
	public void user_updates_account_holder_as_name(String accountHolderName)
	{
		updatenominateDetail.enterAccHoldername(accountHolderName);

	}
	
	@When("^User updates \"([^\"]*)\" as sort code $")
	public void user_updates_as_sort_code(String sortCode) 
	{
		updatenominateDetail.enterSortCode(sortCode);
	}
	
	@When("^User updates \"([^\"]*)\" as account number $")
	public void user_updates_as_account_number(String accountNumber) 
	{
		updatenominateDetail.enterAccountNumber(accountNumber);
	   
	}
	
	@When("^User updates \"([^\"]*)\" as source of funds$")
	public void user_updates_as_source_of_funds(String sorceFund)
	{
		updatenominateDetail.setSourceFund(sorceFund);
	   
	}
	
	@When("^User updates \"([^\"]*)\" as Indicative Deposit Amount $")
	public void user_updates_as_indicative_deposit_amount(String indicativeDepositAmount) 
	{
		updatenominateDetail.enterIndicativeDepositAmount(indicativeDepositAmount);
           
	}
	
	@When("^User updates \"([^\"]*)\" as Interest Payment Preference $")
	public void user_updates_as_interest_payment_preference(String interestPaymentPreference) 
	{
		if(interestPaymentPreference.equals("New Hodge a/c"))
		{
			updatenominateDetail.clickNewHodgeAccount();
		}
	    if(interestPaymentPreference.equals("Nominated a/c"))
	    {
	    	updatenominateDetail.clickNominatedAccount();
		}
	}
	

    @Then("^Nominated bank details update successfully$")
    public void nominated_bank_details_update_successfully()  
    {
        
    }


}
