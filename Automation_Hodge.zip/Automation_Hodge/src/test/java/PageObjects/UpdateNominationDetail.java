package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class UpdateNominationDetail
{

	    WebDriver driver;
	    
	    public UpdateNominationDetail(WebDriver driver)
	    {
	        this.driver=driver;
	        PageFactory.initElements(driver, this);
	    }	  	  
	 
	@FindBy(xpath="//button[@class='edit-additional-data edit-nominee update-nominee']")
	 WebElement btnNominatedetailEdit;
	  
	@FindBy(xpath="//input[@id='accountholdername']")
    WebElement ipTxtAccountHoldername;
	
	@FindBy(xpath="//input[@id='sortcode']")
    WebElement ipTxtSortcode;
	
	@FindBy(xpath="//input[@id='accoutnumber']")
    WebElement ipTxtAccountNumber;
	
	@FindBy(xpath="//select[@name='sourceFund']")
    WebElement selectSourcFund;
	
	@FindBy(xpath="//input[@name='indicativeDeposite']")
    WebElement ipTxtIndicativeDepositAmount;
	
	@FindBy(xpath="//input[@value='New Hodge a/c']")
    WebElement rdBtnNewHodge;
	
	@FindBy(xpath="//input[@value='Nominated a/c']")
    WebElement rdBtnNominatedAccount;
	
	@FindBy(xpath="//button[@class='edit-nominee save-nominee']")
    WebElement btnSave;
	
	@FindBy(xpath="//button[@class='edit-nominee cancel-nominee ']")
    WebElement btnCancel;
	
    public void clickNominatedAccount()
	{
    	rdBtnNominatedAccount.click();
   }
	
	public void clickNominatedDetailEditBtn()
    {
		btnNominatedetailEdit.click();
    } 
	
    public void enterAccHoldername(String accountHolderName)
    {
    	ipTxtAccountHoldername.sendKeys(accountHolderName);
  	  
    }
    
    public void enterSortCode(String sortCode)
    {
    	ipTxtSortcode.clear();
  	    ipTxtSortcode.sendKeys(sortCode);
  	  
    }
    
    public void enterAccountNumber(String accountNumber)
    {
    	ipTxtAccountNumber.clear();
    	ipTxtAccountNumber.sendKeys(accountNumber);
  	  
    }
   
    public void setSourceFund(String sourceFund) 
    {
		
		Select selectSrc=new Select(selectSourcFund);
		selectSrc.selectByVisibleText(sourceFund);
    }
    
    public void enterIndicativeDepositAmount(String indicativeDepositAmount)
    {
    	ipTxtIndicativeDepositAmount.sendKeys(indicativeDepositAmount);
    }  
    
    public void clickNewHodgeAccount()
    {
    	rdBtnNewHodge.click();
    } 
    
  
    
    public void clickSaveProceedBtn()
    {
  	  btnSave.click();
    }
	
    public void clickCancelBtn()
    {
    	btnCancel.click();
    }
}
