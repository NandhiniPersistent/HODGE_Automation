package PageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ReviewInformation 
{

	    WebDriver driver;
	    
	    public ReviewInformation(WebDriver driver)
	    {
	        this.driver=driver;
	        PageFactory.initElements(driver, this);
	    }	  
			@FindBy(xpath="(//*[local-name()='svg'])[1]")
			WebElement chckpersonaldetail;
			
			@FindBy(xpath="//ul/li[@class='list-value'][1]/div[2]")
			WebElement txtTitle;
			
			@FindBy(xpath="//ul/li[@class='list-value'][2]/div[2]")
			WebElement txtFirstName;
			
			@FindBy(xpath="//ul/li[@class='list-value'][3]/div[2]")
			WebElement txtMiddleName;
		
			@FindBy(xpath="//ul/li[@class='list-value'][4]/div[2]")
			WebElement txtLastName;
			
			@FindBy(xpath="//ul/li[@class='list-value'][5]/div[2]")
			WebElement txtDOB;
			
			@FindBy(xpath="//ul/li[@class='list-value'][6]/div[2]")
			WebElement txtNIN;
			
			@FindBy(xpath="//ul/li[@class='list-value'][7]/div[2]")
			WebElement txtMobNo;
			
			@FindBy(xpath="//ul/li[@class='list-value'][8]/div[2]")
			WebElement txtEmailAddress;
			
			@FindBy(xpath="//ul/li[@class='list-data'][1]/div[2]")
			WebElement txtNationality;
			
			@FindBy(xpath="//ul/li[@class='list-data'][2]/div[2]")
			WebElement txtHomeNo;
			
			@FindBy(xpath="//ul/li[@class='list-data'][3]/div[2]")
			WebElement txtResidentialAddress;
			
			@FindBy(xpath="//ul/li[@class='list-data'][4]/div[2]")
			WebElement txtPostalCode;
			
			@FindBy(xpath="//ul/li[@class='list-data'][5]/div[2]")
			WebElement txtUSResident;
			
			@FindBy(xpath="//ul/li[@class='list-data'][6]/div[2]")
			WebElement txtMarketingPreference;
			
			@FindBy(xpath="//ul/li[@class='list-data'][7]/div[2]")
			WebElement txtContactPreference;
			
			@FindBy(xpath="//ul/li[@class='item'][1]/div[2]")
			WebElement txtAccountHolderName;
			
			@FindBy(xpath="//ul/li[@class='item'][2]/div[2]")
			WebElement txtSortCode;
			
			@FindBy(xpath="//ul/li[@class='item'][3]/div[2]")
			WebElement txtAccountNumber;
			
			@FindBy(xpath="//ul/li[@class='item'][4]/div[2]")
			WebElement txtSourceOfFund;
			
			@FindBy(xpath="//ul/li[@class='item'][5]/div[2]")
			WebElement txtIndicativeDepositAmount;
			
		    @FindBy(xpath="//ul/li[@class='item'][6]/div[2]")
			WebElement txtInterestPaymentPreference;
			
		 
		    @FindBy(xpath="//div[@class='reviewDetailsContainer']")
		    List<WebElement>personal_additionalInfo;
		    
		    @FindBy(xpath="(//*[local-name()='svg'])[2]]")
		    WebElement chcknominateddetail;
			
		    @FindBy(xpath="//div[@class='review-info-wrapper']")
		    List<WebElement>nominatedInfo;
		    
		    
		    @FindBy(xpath="//input[@name='firstTerm']")
		    WebElement chckboxReadTermsConditions;
		    
		    @FindBy(xpath="//input[@name='secondTerm']")
		    WebElement chckboxReadFSCSDoc;
		    
		    @FindBy(xpath="//input[@name='thirdTerm']")
		    WebElement chckboxDeclareInfo;
		    
		    @FindBy(xpath="//input[@name='fourTerm']")
		    WebElement chckboxTicktoConfirm;
		   
		    @FindBy(xpath="//button[@class='edit-nominee save-nominee disabled']")
		    WebElement btnSubmit;
		    
		    @FindBy(xpath="//a[@class='exit-wrap']")
		    WebElement btnExit;
		    
		    public void clickPersonalDetails()
		    {
		    	chckpersonaldetail.click();
		    }
		    
		
		    public void clickNominatedDetails()
		    {
		    	chcknominateddetail.click();
		    }
		    
		    public void clickFirstTerm()
		    {
		    	chckboxReadTermsConditions.click();
		    }
			 
		    public void clickSecondTerm()
		    {
		    	chckboxReadFSCSDoc.click();
		    }
			
		    public void clickThirdTerm()
		    {
		    	chckboxDeclareInfo.click();
		    }
			
		    public void clickFourthTerm()
		    {
		    	chckboxTicktoConfirm.click();
		    }
			
		    public void clickSubmitBtn()
		    {
		    	btnSubmit.click();
		    }
		    
		    public void clickExitBtn()
		    {
		    	btnExit.click();
		    }
		
			public String getTxtTitle()
			{
				return txtTitle.getText();
			}
		
			public String getTxtFirstName() {
				return txtFirstName.getText();
			}
		
			public String getTxtMiddleName() {
				return txtMiddleName.getText();
			}
		
			public String getTxtLastName() {
				return txtLastName.getText();
			}
		
			public String getTxtDOB() {
				return txtDOB.getText();
			}
		
			public String getTxtNIN() {
				return txtNIN.getText();
			}
		
			public String getTxtMobNo() {
				return txtMobNo.getText();
			}
		
			public String getTxtEmailAddress() {
				return txtEmailAddress.getText();
			}
		
			public String getTxtNationality() {
				return txtNationality.getText();
			}
		
			public String getTxtHomeNo() {
				return txtHomeNo.getText();
			}
		
			public String getTxtResidentialAddress() {
				return txtResidentialAddress.getText();
			}
		
			public String getTxtPostalCode() {
				return txtPostalCode.getText();
			}
		
			public String getTxtUSResident() {
				return txtUSResident.getText();
			}
		
			public String getTxtMarketingPreference() {
				return txtMarketingPreference.getText();
			}
		
			public String getTxtContactPreference() {
				return txtContactPreference.getText();
			}
		
			public String getTxtAccountHolderName() {
				return txtAccountHolderName.getText();
			}
		
			public String getTxtSortCode() {
				return txtSortCode.getText();
			}
		
			public String gettxtAccountNumber() {
				return txtAccountNumber.getText();
			}
		
			public String getTxtSourcOfFund() {
				return txtSourceOfFund.getText();
			}
		
			public String getTxtIndicativeDepositAmount() {
				return txtIndicativeDepositAmount.getText();
			}
		
			public String getTxtInterestPaymentPreference() {
				return txtInterestPaymentPreference.getText();
			}
		    
		    
		    
    
    
    
    
    
}
