package PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.lu.dann;

public class NominatedBankDetails
{
	 WebDriver driver;
	    
	    public NominatedBankDetails(WebDriver driver)
	    {
	        this.driver=driver;
	        PageFactory.initElements(driver, this);
	    }
	 
      @FindBy(xpath="(//input[@type='text'])[1]")
      WebElement ipTxtAccountholderName;
      
      @FindBy(xpath="(//input[@type='text'])[2]")
	  WebElement ipTxtSortCode1;
	  
      @FindBy(xpath="(//input[@type='text'])[3]")
  	  WebElement ipTxtSortCode2;
      
      @FindBy(xpath="(//input[@type='text'])[4]")
  	  WebElement ipTxtSortCode3;
      
      @FindBy(xpath="(//input[@type='text'])[5]")
      WebElement ipTxtAccountNumber;	  
      
      @FindBy(xpath="(//input[@type='text'])[6]")
      WebElement ipTxtReAccountNumber;
      
      @FindBy(xpath="//select[@class='inputBoxDropdown']")
      WebElement ipTxtSourceFund;
      
      @FindBy(xpath="(//input[@type='text'])[7]")
      WebElement ipTxtIndicativeDepositAmount;
    
      @FindBy(xpath="(//span[@class='checkmark'])[1]")
      WebElement chkBoxNewHodgeAccount;
      
      @FindBy(xpath="(//span[@class='checkmark'])[2]")
      WebElement chkBoxNominatedAccount;
      
      @FindBy(xpath="//button[contains(text(),'Save & Proceed')]")
      WebElement btnSave;
     
      @FindBy(xpath="//button[@class='edit-nominee cancel-nominee ']")
      WebElement btnCancel;
      
      public void enterAccHolderName(String name)
      {
    	  ipTxtAccountholderName.clear();
    	  ipTxtAccountholderName.sendKeys("Dev Demo");
    	  
      }
      
      public void enterSortCode1(String sortcode1)
      {
    	  ipTxtSortCode1.clear();
    	  ipTxtSortCode1.sendKeys(sortcode1);
    	  
      }
      
      
      public void enterSortCode2(String sortcode2)
      {
    	  ipTxtSortCode2.sendKeys(sortcode2);
    	  
      }

      public void enterSortCode3(String sortcode3)
      {
    	  ipTxtSortCode3.sendKeys(sortcode3);
    	  
      } 
      
      public void enterAccNumber(String Accnum)
      {
    	  ipTxtAccountNumber.sendKeys(Accnum);
    	  
      } 
      public void enterReenterAccNumber(String ReAccNum)
      {
    	  ipTxtReAccountNumber.sendKeys(ReAccNum);
    	  
      }
      
      /*
      public void enterSrcFund(String srcfund)
      {
    	  ipTxtSourceFund.sendKeys(srcfund);
      }  
      */
      
  	  public void enterSourcFund(String SrcFund) 
  	  {
  		
  		Select selectSrc=new Select(ipTxtSourceFund);
  		selectSrc.selectByVisibleText(SrcFund);;
  	  }
      
      public void enterIndicativeDepositAmount(String IndDepAmt)
      {
    	  ipTxtIndicativeDepositAmount.sendKeys(IndDepAmt);
      }  
      
      public void ClickNewHodgeAccount()
      {
    	  chkBoxNewHodgeAccount.click();;
      } 
      
      public void ClickNominatedAccount()
      {
    	  chkBoxNominatedAccount.click();;
      }
      
      public void ClickSaveProceedBtn()
      {
    	  btnSave.click();;
      }
      
      public void ClickCancelBtn()
      {
      	btnCancel.click();;
      }


}