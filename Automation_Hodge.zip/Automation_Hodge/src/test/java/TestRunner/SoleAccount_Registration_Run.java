package TestRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;


@RunWith (Cucumber.class)
@CucumberOptions(

		features = ".//src/test/java/features/SoleAccount_Registration.feature",
		glue = "StepDefinition",
		monochrome = true,
		dryRun = false,
		plugin = {"pretty", "html:target/cucmber-reports/reports1.html"}
		
	  )

public class SoleAccount_Registration_Run
{
			
}

