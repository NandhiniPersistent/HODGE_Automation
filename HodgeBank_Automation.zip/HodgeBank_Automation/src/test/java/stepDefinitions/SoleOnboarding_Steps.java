package stepDefinitions;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import DriverSetup.SeleniumDrivers;
import PageObjects.PageObj_SoleOnboarding;
import Util.ExcelReader;
import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SoleOnboarding_Steps {
	
	static private WebDriver driver;
	private static String title;	
	private PageObj_SoleOnboarding SolePageObj = new PageObj_SoleOnboarding(SeleniumDrivers.getDriver());
	
	
	
	@Given("^User opens the browser and launches the web URL$")
    public void user_opens_the_browser_and_launches_the_web_url() {
		SeleniumDrivers.getDriver().get("https://d24k3akkz9t4ai.cloudfront.net/");

    }

    @When("^user checks the title of the page$")
    public void user_checks_the_title_of_the_page() {
        title = SolePageObj.getPageTitle();
        ;
      
    }
    
    @And("^title of the page should be \"([^\"]*)\"$")
    public String title_of_the_page_should_be_something(String expectedTitleName) throws InterruptedException{
    	
    	System.out.println("Title of the page is " + title);
    	return title;
    	
    }
    

    @And("^user scrolls down and clicks on the checkbox with text For tax purposes I am a UK Resident$")
    public void user_scrolls_down_and_clicks_on_the_checkbox_with_text_for_tax_purposes_i_am_a_uk_resident() throws InterruptedException{
    	Thread.sleep(1000);
    	SolePageObj.IconfirmCheckbox();
    	//SolePageObj.exitButtonCheck();
    	
    }

    @Then("^user clicks on \"([^\"]*)\" button$")
    public void user_clicks_on_something_button(String strArg1) throws InterruptedException {
    	Thread.sleep(1000);
    	SolePageObj.confirmAndProceed();  
    }
    
    @And("^Popup opens with Is this Joint application with Yes and No buttons$")
    public void popup_opens_with_is_this_joint_application_with_yes_and_no_buttons(){
    	
    	System.out.println("Joint Application Popup displayed");
        
    }

    @Then("^User clicks on \"([^\"]*)\" button on the popup$")
    public void user_clicks_on_something_button_on_the_popup(String strArg1) throws InterruptedException {
    	SolePageObj.JointApplicationAlert();
        
    }

    @Then("^Registration Process for Sole Onboarding page loads$")
    public void registration_process_for_sole_onboarding_page_loads() throws Throwable {
        System.out.println("Registration page is loaded");
    }

    //Registration Page 
    @Then("^the user navigates to personal details page in sole onboarding process$")
    public void the_user_navigates_to_personal_details_page_in_sole_onboarding_process() throws Throwable {
    	
    	SolePageObj.RegistrationPageverify();
        
    }
    
    @When("^user fills the personal details from given \"([^\"]*)\" and rownumber (.+)$")
    public void user_fills_the_personal_details_from_given_something_and_rownumber(String sheetName, Integer rowNumber) throws InvalidFormatException, IOException, InterruptedException {
        
    	ExcelReader reader = new ExcelReader();
		List<Map<String,String>> testData = 
				reader.getData("D:/AutomationStructure/HodgeBank_Automation/src/test/resources/Data/SoleonboardingData.xlsx", sheetName);
		
		String prefix = testData.get(rowNumber).get("Prefix");
		String firstName = testData.get(rowNumber).get("FirstName");
		String middleName = testData.get(rowNumber).get("MiddleName");
		String lastName = testData.get(rowNumber).get("LastName");
		String DD = testData.get(rowNumber).get("DD");
		String MM = testData.get(rowNumber).get("MM");
		String YYYY = testData.get(rowNumber).get("YYYY");
		String NIN1 = testData.get(rowNumber).get("NIN1");
		String NIN2 = testData.get(rowNumber).get("NIN2");
		String NIN3 = testData.get(rowNumber).get("NIN3");
		String NIN4 = testData.get(rowNumber).get("NIN4");
		String NIN5 = testData.get(rowNumber).get("NIN5");
		
		SolePageObj.fillPersonalDetails(prefix, firstName, middleName, lastName, DD, MM, YYYY, NIN1, NIN2, NIN3, NIN4, NIN5);
    }


    @And("^User clicks on Save & Proceed button$")
    public void user_clicks_on_save_proceed_button() throws InterruptedException {
    	SolePageObj.PersonalDet_SaveandProceed();
    }
    
    @Then("^Confirm Details Popup with confirm button$")
    public void confirm_details_popup_with_confirm_button() throws Throwable {
    	SolePageObj.PersonalDet_ConfirmPopup();
    }

    @Then("^User clicks on \"([^\"]*)\" button in the Popup$")
    public void user_clicks_on_something_button_in_the_popup(String strArg1) throws Throwable {
        SolePageObj.PersonalDet_ConfirmBtn();
        
    }

   





}
