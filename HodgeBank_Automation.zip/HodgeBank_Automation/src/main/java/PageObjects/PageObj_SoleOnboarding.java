package PageObjects;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PageObj_SoleOnboarding {
	
	

	private WebDriver driver;

	

	/******Constructor of the Page objects class for Sole Onboarding******/

	public PageObj_SoleOnboarding(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);

	}
	
	//Actions Keyboard
	public void keyboardActions() {
		Actions action = new Actions(driver);
    	//action.sendKeys(Keys.ARROW_DOWN);
    	action.sendKeys(Keys.ENTER);
    	action.perform();
	}

	//Before you Apply - BefApply
	@FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[10]/div[1]/*[name()='svg'][1]/*[name()='g'][1]/*[name()='g'][1]/*[name()='rect'][1]")
	//@FindBy(xpath = "(//*[local-name()='svg'])[1]")
	WebElement BefApplyIconfirmCheckBox;

	@FindBy(xpath = "//button[text()='Confirm & Proceed']")
	WebElement BefApplyconfirmAndProceed;
	
	@FindBy(xpath="//a[contains(text(),'Exit')]") 
	WebElement exitButtonElement;
	
	//Is this Joint Application POPUP - JointPopup

	@FindBy(xpath = "//div[text()='No']")
	WebElement JointPopupNo;
	
	@FindBy(xpath = "//div[text()='Yes']")
	WebElement JointPopupYes;
	
	@FindBy(xpath="//div[text()='Registration Process']")
	WebElement RegistrationPagetext;

	//Personal Details page - PersDet
	@FindBy(xpath = "//div[text()='Select Prefix']")
	WebElement persDetPrefix;
	
	@FindBy(xpath="//ul[contains(@role,'listbox')]")
	WebElement persDetPrefixOpt;

	@FindBy(xpath = "//div[text()='First Name*']")
	WebElement persDetFirstName;

	@FindBy(xpath = "//div[text()='Middle Name']")
	WebElement persDetMiddleName;

	@FindBy(xpath = "//div[text()='Last Name*']")
	WebElement persDetLastName;

	@FindBy(xpath = "//input[contains(@placeholder,'DD')]")
	WebElement persDetDD;

	@FindBy(xpath = "//input[contains(@placeholder,'MM')]")
	WebElement persDetMM;

	@FindBy(xpath = "//input[contains(@placeholder,'YYYY')]")
	WebElement persDetYYYY;

	//National Identification Number - NIN
	@FindBy(xpath = "//input[contains(@placeholder,'QQ')]")
	WebElement persDetNIN1;

	@FindBy(xpath = "//input[contains(@placeholder,'12')]")
	WebElement persDetNIN2;

	@FindBy(xpath = "//input[contains(@placeholder,'34')]")
	WebElement persDetNIN3;

	@FindBy(xpath = "//input[contains(@placeholder,'56')]")
	WebElement persDetNIN4;

	@FindBy(xpath = "//input[contains(@placeholder,'C')]")
	WebElement persDetNIN5;

	@FindBy(css = ".customLoginBtn.ceraProMedium.btnMarginTop")
	WebElement persDetSaveAndProceed;
	
	@FindBy(xpath = "//div[@class='sixteen B1B1B ceraBasicRegular modalContent']")
	WebElement persDetConfirmPopup;
	
	@FindBy(xpath = "//button[text()='Confirm']")
	WebElement persDetConfirmBtn;

	//Contact information - contactInfo
	

	@FindBy(css = "input[aria-label='Small']")
	WebElement contactInfoMobile;
	
	@FindBy(xpath = "//button[contains(@data-testid,'sendcode')]")
	WebElement contactInfoSendCode;
	
	//Mobile Verification - mobVerify
	
	@FindBy(css = "input[aria-label='Please enter verification code. Digit 1']")
	WebElement mobVerify1;
	
	@FindBy(css = "input[aria-label='Digit 2']")
	WebElement mobVerify2;
	
	@FindBy(css = "input[aria-label='Digit 3']")
	WebElement mobVerify3;
	
	@FindBy(css = "input[aria-label='Digit 4']")
	WebElement mobVerify4;
	
	@FindBy(css = "input[aria-label='Digit 5']")
	WebElement mobVerify5;
	
	@FindBy(css = "input[aria-label='Digit 6']")
	WebElement mobVerify6;
	


	public String getPageTitle() {
		return driver.getTitle();
		
	}
	
	public void IconfirmCheckbox() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 600)");
		Thread.sleep(1000);
		BefApplyIconfirmCheckBox.click();

	}

	public void confirmAndProceed() {
		BefApplyconfirmAndProceed.click();
			
	}
	
	public boolean exitButtonCheck() {
		return exitButtonElement.isDisplayed();
	}
	
	public void JointApplicationAlert() throws InterruptedException{
		Thread.sleep(1000);
		JointPopupNo.click();
		
	}

	public void RegistrationPageverify() throws InterruptedException {
		System.out.println(RegistrationPagetext);
		String ActualUrl = "https://d3t331mvgv7oxd.cloudfront.net/Register";	
		String UserOn = driver.getCurrentUrl();
		
		if(ActualUrl.equals(UserOn)) {
			System.out.println("User is on Registration Process Page");
		}
		else {
			System.out.println("User in "+ UserOn);
		}
		
		Thread.sleep(1000);
	}
	
	//@SuppressWarnings("deprecation")
	public void fillPersonalDetails(String prefix, String FirstName,String MiddleName, String LastName, String DD, String MM, String YYYY, String NIN1,String NIN2, String NIN3, String NIN4,String NIN5) throws InterruptedException {
		
		persDetPrefix.click();
		System.out.println(prefix);
		driver.findElement(By.xpath("//li[@data-value='"+prefix+"']")).click();
		//persDetPrefixOpt.sendKeys(prefix);
		Thread.sleep(1000);
		//keyboardActions();
		
		
//		List<WebElement> All = driver.findElements(By.xpath("//*[@id='menu-']/div[3]/ul/li"));
//		int size = All.size();
//		System.out.println(size);
//		Thread.sleep(4000);
//		for(int j=0;j<size;j++)
//		{
//		if(All.get(j).getText().equals(prefix)){
//			All.get(j).click();
//			keyboardActions();
//			System.out.println("InsideLOOP");
//			break;
//			
//		}
//		}
		
		//keyboardActions();
		
		
//		JavascriptExecutor jse = (JavascriptExecutor) driver;	
//		jse.executeScript("window.scrollBy(0,500)", "");
		Thread.sleep(2000);
		persDetFirstName.sendKeys(FirstName);
		
		persDetFirstName.sendKeys(MiddleName);
		
		persDetFirstName.sendKeys(LastName);
		
 	
    	persDetDD.click();
    	persDetDD.sendKeys(DD);
    	keyboardActions();
		
    	persDetMM.click();
    	persDetMM.sendKeys(MM);
    	keyboardActions();
    	
    	
    	persDetYYYY.click();
    	persDetYYYY.sendKeys(YYYY);
    	keyboardActions();
		
		persDetNIN1.sendKeys(NIN1);
		persDetNIN2.sendKeys(NIN2);
		persDetNIN3.sendKeys(NIN3);
		persDetNIN4.sendKeys(NIN4);
		persDetNIN5.sendKeys(NIN5);
		Thread.sleep(1000);
	}

	
	public void PersonalDet_SaveandProceed() throws InterruptedException {
		persDetSaveAndProceed.click();
		
	}
	
	public void PersonalDet_ConfirmPopup() {
		System.out.println(persDetConfirmPopup.getText());
	}
	
	public void PersonalDet_ConfirmBtn() throws InterruptedException {
		persDetConfirmBtn.click();
	}

}




