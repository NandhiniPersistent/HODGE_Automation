package page_factory_BeforeYouApply;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class mobileNumber_POM {
	WebDriver driver;
	public mobileNumber_POM(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//div[contains(text(),'Contact Verification')]") WebElement headingElement;
	@FindBy(xpath="//input") WebElement mobileNumberElement;
	@FindBy(xpath="//button[contains(text(),'Send Code')]") WebElement sendCodeElement;
	@FindBy(xpath="//div[contains(text(),'Mobile Number Verification')]") WebElement otpPopUpElement;
	
	
	public void isUserOnPage() {
		String AcualUrl="https://d3t331mvgv7oxd.cloudfront.net/MobileRegister";
		String UserOn= driver.getCurrentUrl();
		
		if(AcualUrl.equals(UserOn)) {
			System.out.println("User is on Mobile Registarion Process page");
		}
		else {
			System.out.println("User is on "+UserOn);
		}
	}
	
	public void mobile(String number) {
		mobileNumberElement.sendKeys(number);
	}
	
	public void sendCode() {
		sendCodeElement.click();
	}
	
	public void otpPopUp() {
		otpPopUpElement.isDisplayed();
	}
	
}
