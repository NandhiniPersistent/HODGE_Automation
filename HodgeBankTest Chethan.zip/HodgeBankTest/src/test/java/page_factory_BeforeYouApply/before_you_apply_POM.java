package page_factory_BeforeYouApply;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class before_you_apply_POM {	
	WebDriver driver;
	
	public before_you_apply_POM(WebDriver driver) {
		this.driver =driver;
		PageFactory.initElements(driver, this);	
	}
	
	@FindBy(xpath="(//*[local-name()='svg'])[1]") WebElement IconfrimCheckBoxElement;
	@FindBy(xpath="//a[contains(text(),'Exit')]") WebElement exitButtonElement;
	@FindBy(xpath="//button[contains(text(),'Confirm & Proceed')]") WebElement proceedButtonElement;
	@FindBy(xpath="(//div[contains(text(),'No')])[3]") WebElement soloAccountElement;
	@FindBy(xpath="//div[contains(text(),'Yes')]") WebElement jointAccountElement;

	public void isUserOnPage() {
		String homePage ="https://d3t331mvgv7oxd.cloudfront.net/";
		String UserOn = driver.getCurrentUrl();
		if(homePage.equals(UserOn)) {
			System.out.println("User is on criteria Page");
		}
		else {
			System.out.println("User is on "+UserOn);
		}
	
	}
	public void checkBox() {
		IconfrimCheckBoxElement.click();
	}
	
	public boolean exitButtonCheck() {
		return exitButtonElement.isDisplayed();
	}
	
	public void ProceedButton() {
		proceedButtonElement.click();	
	}
	
	public void soloAccount() {
		soloAccountElement.click();
	}

	public void jointAccount() {
		jointAccountElement.click();
	}
}

	
