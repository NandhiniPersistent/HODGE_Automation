package page_factory_BeforeYouApply;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Registration_Process_POM {
	WebDriver driver;
	
	public Registration_Process_POM(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[contains(text(),'Registration Process')]") WebElement headingElement;
	
	@FindBy(xpath="(//*[@id='root']//input[@class='inputBox'])[1]") WebElement firstNameElement;
	@FindBy(xpath="(//*[@id='root']//input[@class='inputBox'])[2]") WebElement middleNameElement;
	@FindBy(xpath="(//*[@id='root']//input[@class='inputBox'])[3]") WebElement lastNameElement;
	
	@FindBy(xpath="//div[@id='demo-simple-select']") WebElement dropDownElement;
	@FindBy(xpath="//li[@data-value='Mr']") WebElement mrSelectorElement;
	
	@FindBy(xpath="//*[@placeholder='DD']") WebElement dayElement;
	@FindBy(xpath="//*[@placeholder='MM']") WebElement monthElement;
	@FindBy(xpath="//*[@placeholder='YYYY']") WebElement yearElement;
	
	@FindBy(xpath="//*[@class='insuranceInputFlex']//input[1]") WebElement ninSelector_one;
	@FindBy(xpath="//*[@class='insuranceInputFlex']//input[2]") WebElement ninSelector_two;
	@FindBy(xpath="//*[@class='insuranceInputFlex']//input[3]") WebElement ninSelector_three;
	@FindBy(xpath="//*[@class='insuranceInputFlex']//input[4]") WebElement ninSelector_four;	
	@FindBy(xpath="//*[@class='insuranceInputFlex']//input[5]") WebElement ninSelector_five;

	@FindBy(xpath="//button[contains(text(),'Save & Proceed')]") WebElement saveAndProceedBtn;
	@FindBy(xpath="//button[contains(text(),'Confirm')]") WebElement confirmBtnElement;	
	
	
	public void isUserOnPage() {
		String AcualUrl = "https://d3t331mvgv7oxd.cloudfront.net/Register";	
		String UserOn = driver.getCurrentUrl();
		
		if(AcualUrl.equals(UserOn)) {
			System.out.println("User is on Registration Process Page");
		}
		else {
			System.out.println("User in "+ UserOn);
		}
	}
	
//NAME Filling
	
	public void preFixSelector(String prefix) {
		dropDownElement.click();	
		driver.findElement(By.xpath("//li[@data-value='"+prefix+"']")).click();
		//mrSelectorElement.click();
	}
	
	public void firstName(String firstName) {
		firstNameElement.sendKeys(firstName);
	}
	
	public void middleName(String middleName) {
		middleNameElement.sendKeys(middleName);
	}
	
	public void lastName(String lastName) {
		lastNameElement.sendKeys(lastName);
	}
	
//	DATE FILLING
	
	public void keyboardAction() {
		Actions action = new Actions(driver);
    	action.sendKeys(Keys.ARROW_DOWN).perform();
    	action.sendKeys(Keys.ENTER).perform();
	}
	
    public void date(String date) {
    	dayElement.click();
    	dayElement.sendKeys(date);
    	keyboardAction();	
    }
      
	public void month(String month) {
		monthElement.click();
		monthElement.sendKeys(month);
		keyboardAction();
	}

	public void year(String year) {
		yearElement.click();
		yearElement.sendKeys(year);
		keyboardAction();
	}
	
	
//NIN NUMBERS

	public void nin_one(String one) {
		ninSelector_one.sendKeys(one);
	}
	
	public void nin_two(String two) {
		ninSelector_two.sendKeys(two);
	}
	
	public void nin_three(String three) {
		ninSelector_three.sendKeys(three);
	}
	public void nin_four(String four) {
		ninSelector_four.sendKeys(four);
	}
	public void nin_five(String five) {
		ninSelector_five.sendKeys(five);
					
	}
	
//SAVE AND PROCEED
	
	public void saveAndProceed() {	
		saveAndProceedBtn.click();
	}
	
	public void confirmBtn() {
		confirmBtnElement.click();
	}

}

