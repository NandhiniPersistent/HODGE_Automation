package StepDefination;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import DataDriven.ExcelUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

import page_factory_BeforeYouApply.Registration_Process_POM;
import page_factory_BeforeYouApply.before_you_apply_POM;
import page_factory_BeforeYouApply.mobileNumber_POM;

public class loginHodgeSteps {
	static private WebDriver driver;
	before_you_apply_POM before_you_apply;
	Registration_Process_POM registration_process;
	mobileNumber_POM mobile_number;

	String homepage="https://d3t331mvgv7oxd.cloudfront.net/";
	ExcelUtils excel= new ExcelUtils("src/test/resources/ExcelFile/TestData.xlsx");
	List<String> excel_data = excel.readExcelData("user_details");	
	
//-----------------------BEFORE YOU APPLY PAGE-------------------------------------------------

	@Given("User on Hodge Bank Website")
	public void user_on_hodge_bank_website() throws InterruptedException {
		
		WebDriverManager.firefoxdriver().setup();
		driver = new FirefoxDriver();	
		driver.manage().window().maximize();
		driver.get(homepage);	
		Thread.sleep(3000);
		before_you_apply = new before_you_apply_POM(driver);	
		
		before_you_apply.isUserOnPage();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)", "");
	}

	@And("User clicks on the i confirm checkbox")
	public void user_clicks_on_the_i_confirm_checkbox() throws InterruptedException {

		
		before_you_apply.checkBox();
		before_you_apply.exitButtonCheck();	
		Thread.sleep(3000);
	}

	@When("User click on Confirm and Proceed")
	public void user_click_on_confirm_and_proceed() {
		before_you_apply.ProceedButton();
	}
	
	@Then("User Slect solo or joint journey")
	public void user_slect_solo_or_joint_journey() {
		before_you_apply.soloAccount();		
		//before_you_apply.jointAccount();
	}


//--------------------------------------Registration Process--------------------------------------
	
	@Given("User in Registration Procees Page")
	public void user_in_registration_procees_page() {
		registration_process= new Registration_Process_POM(driver);
		
		registration_process.isUserOnPage();		
	}

	@And("User select Prefix")
	public void user_select_prefix() {
		registration_process.preFixSelector(excel_data.get(0));

		JavascriptExecutor jse = (JavascriptExecutor) driver;	
		jse.executeScript("window.scrollBy(0,500)", "");

	}

	@And("User Select firstName")
	public void user_select_first_name() {
		registration_process.firstName(excel_data.get(1));
	}
	
	@And("USer Select middleName")
	public void u_ser_select_middle_name() {
		registration_process.middleName(excel_data.get(2));
	}

	@And("User Select Last_name")
	public void user_select_last_name() {
		registration_process.lastName(excel_data.get(3));
	}
	
	@And("User Select Date Of Birth")
	public void user_select_date_of_birth() {
		registration_process.date(excel_data.get(4));
		registration_process.month(excel_data.get(5));
		registration_process.year(excel_data.get(6));

	}
	
	@And("User Enter the NIN Number")
	public void user_enter_the_nin_number() {
		registration_process.nin_one(excel_data.get(7));
		registration_process.nin_two(excel_data.get(8));
		registration_process.nin_three(excel_data.get(9));
		registration_process.nin_four(excel_data.get(10));
		registration_process.nin_five(excel_data.get(11));
	}

	@When("User clicked on Save and Proced")
	public void user_clicked_on_save_and_proced() {
		registration_process.saveAndProceed();
	}

	@Then("User Navigate to the next Page")
	public void user_navigate_to_the_next_page() throws InterruptedException {
		Thread.sleep(10000);
		registration_process.confirmBtn();

	}

//---------------------------------MOBILE NUMBER VALIDATION---------------------------------------------

	@Given("User on Hodge Mobile number Registration Page")
	public void user_on_hodge_mobile_number_registration_page() {
		mobile_number= new mobileNumber_POM(driver);
		
		mobile_number.isUserOnPage();		
	}

	@And("User enter the mobile number")
	public void user_enter_the_mobile_number() {
		mobile_number.mobile(excel_data.get(12));
	}

	@When("User Click on Confirm")
	public void user_click_on_confirm() {
		mobile_number.sendCode();
	}

	@Then("User get OTP to his Mobile number")
	public void user_get_otp_to_his_mobile_number() throws InterruptedException {
		Thread.sleep(300);
		mobile_number.otpPopUp();

	}
}

