package DataDriven;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
	
	XSSFWorkbook workbook= null;
	FileInputStream fis =null;
	XSSFSheet sheet= null;
	XSSFRow headerRow =null;
	XSSFRow row=null;
	XSSFCell cell =null;
	
	int colNum = 0;
	int rowCount = 0;
	String value;
	List<String> columnData = new ArrayList<String>();
	
	public ExcelUtils(String filepath) {
		try {
			fis = new FileInputStream(filepath);
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found Please check the FilePath --> "+filepath);
		}
		try {
			workbook = new XSSFWorkbook(fis);
			fis.close();
		} catch (IOException e1) {
			System.out.println(e1);
		}
			
	}
	
	public List<String> readExcelData(String sheetName){
		DataFormatter format =new DataFormatter();
		sheet =workbook.getSheet(sheetName);
		headerRow= sheet.getRow(0);

		rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
		
		for(int j=1;j<=rowCount;j++) {
			row = sheet.getRow(j);
			
			for(int i=0;i<row.getLastCellNum();i++) {

				cell = row.getCell(i);
				value = format.formatCellValue(cell);
				columnData.add(value);
			}

			}
		
		return columnData;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
