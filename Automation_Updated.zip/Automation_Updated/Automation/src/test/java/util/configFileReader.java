package util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class configFileReader {

		
		private static Properties properties;
		private final String propertyFilePath= "//src//test//resources//config//config.properties";


		/**
		 * This method is used to load the properties from config.properties file
		 * @return it returns Properties prop object
		 */
		
		public Properties init_prop() {

			properties = new Properties();
			try {
				FileInputStream ip = new FileInputStream(propertyFilePath);
				properties.load(ip);

			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			return properties;

		}
		

		
		/*
		 * public long getImplicitlyWait() { String implicitlyWait =
		 * properties.getProperty("implicitlyWait"); if(implicitlyWait != null) return
		 * Long.parseLong(implicitlyWait); else throw new
		 * RuntimeException("implicitlyWait not specified in the Configuration.properties file."
		 * ); }
		 * 
		 * 
		 * public String getApplicationUrl() { String url =
		 * properties.getProperty("url"); if(url != null) return url; else throw new
		 * RuntimeException("url not specified in the Configuration.properties file.");
		 * }
		 */
		


}
