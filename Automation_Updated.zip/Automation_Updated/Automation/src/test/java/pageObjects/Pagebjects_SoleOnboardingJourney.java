package pageObjects;

import java.util.List;

import org.apache.poi.ss.formula.atp.Switch;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;


public class Pagebjects_SoleOnboardingJourney {


	Pagebjects_SoleOnboardingJourney pageObjSole = null;
	WebDriver driver = null;
	

	public Actions action;
	public JavascriptExecutor je;


	//******Constructor of the Page objects class for Sole Onboarding******/

	public Pagebjects_SoleOnboardingJourney(WebDriver driver) {
		this.driver=driver;

	}

	//Before you Apply - BefApply
	@FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[10]/div[1]/*[name()='svg'][1]")
	WebElement BefApplyIconfirmCheckBox;

	@FindBy(xpath = "//button[text()='Confirm & Proceed']")
	WebElement BefApplyconfirmAndProceed;

	//Personal Details page - PersDet
	@FindBy(xpath = "//div[text()='Select Prefix']")
	WebElement persDetPrefix;

	@FindBy(xpath = "//div[text()='First Name*']")
	WebElement persDetFirstName;

	@FindBy(xpath = "//div[text()='Middle Name']")
	WebElement persDetMiddleName;

	@FindBy(xpath = "//div[text()='Last Name*']")
	WebElement persDetLastName;

	@FindBy(xpath = "//input[contains(@placeholder,'DD')]")
	WebElement persDetDD;

	@FindBy(xpath = "//input[contains(@placeholder,'MM')]")
	WebElement persDetMM;

	@FindBy(xpath = "//input[contains(@placeholder,'YYYY')]")
	WebElement persDetYYYY;

	//National Identification Number - NIN
	@FindBy(xpath = "//input[contains(@placeholder,'QQ')]")
	WebElement persDetNIN1;

	@FindBy(xpath = "//input[contains(@placeholder,'12')]")
	WebElement persDetNIN2;

	@FindBy(xpath = "//input[contains(@placeholder,'34')]")
	WebElement persDetNIN3;

	@FindBy(xpath = "//input[contains(@placeholder,'56')]")
	WebElement persDetNIN4;

	@FindBy(xpath = "//input[contains(@placeholder,'C')]")
	WebElement persDetNIN5;

	@FindBy(css = ".customLoginBtn.ceraProMedium.btnMarginTop")
	WebElement persDetSaveAndProceed;
	
//******************************************************************************************************//	
	
	//Marketing And Contact Preferences/Communication Channels On Additional Page- AdditionalInfo
	
    @FindBy(xpath="(//*[local-name()='svg'])[4]")
    WebElement AdditionalInfoSMSMarketPrefernce;
	
    @FindBy(xpath="(//*[local-name()='svg'])[5]")
    WebElement AdditionalInfoEmailMarketPrefernce;
	
    @FindBy(xpath="(//*[local-name()='svg'])[6]")
    WebElement AdditionalInfoNOMarketingUpdate;
	
    @FindBy(xpath="(//*[local-name()='svg'])[8]")
    WebElement AdditionalInfoEmailContactPrefernce;
    
    @FindBy(xpath="(//*[local-name()='svg'])[9]")
    WebElement AdditionalInfoTelephoneContactPrefernce;
    
    @FindBy(xpath="//button[@class='customLoginBtn btnMarginTop ceraProMedium']")
    WebElement AdditionalInfoSaveAndProceed;

	//Nominated Bank Details - NomBankDet
	
    @FindBy(xpath="(//input[@type='text'])[1]")
    WebElement NomBankDetAccountholderName;
    
    @FindBy(xpath="(//input[@type='text'])[2]")
	  WebElement NomBankDetSortCode1;
	  
    @FindBy(xpath="(//input[@type='text'])[3]")
	  WebElement NomBankDetSortCode2;
    
    @FindBy(xpath="(//input[@type='text'])[4]")
	  WebElement NomBankDetSortCode3;
    
    @FindBy(xpath="(//input[@type='text'])[5]")
    WebElement NomBankDetAccountNumber;	  
    
    @FindBy(xpath="(//input[@type='text'])[6]")
    WebElement NomBankDetReAccountNumber;
    
    @FindBy(xpath="//select[@class='inputBoxDropdown']")
    WebElement NomBankDetSourceFund;
    
    @FindBy(xpath="(//input[@type='text'])[7]")
    WebElement NomBankDetIndicativeDepositAmount;
  
    @FindBy(xpath="(//span[@class='checkmark'])[1]")
    WebElement NomBankDetNewHodgeAccount;
    
    @FindBy(xpath="(//span[@class='checkmark'])[2]")
    WebElement NomBankDetNominatedAccount;
    
    @FindBy(xpath="//button[contains(text(),'Save & Proceed')]")
    WebElement NomBankDetSave;
   
    @FindBy(xpath="//button[@class='edit-nominee cancel-nominee ']")
    WebElement NomBankDetCancel;
  
   //UpdateNominationDetail-UpdateNomDetail
    
   	@FindBy(xpath="//button[@class='edit-additional-data edit-nominee update-nominee']")
   	 WebElement UpdateNomDetailEdit;
   	  
   	@FindBy(xpath="//input[@id='accountholdername']")
       WebElement UpdateNomDetailAccountHoldername;
   	
   	@FindBy(xpath="//input[@id='sortcode']")
       WebElement UpdateNomDetailSortcode;
   	
   	@FindBy(xpath="//input[@id='accoutnumber']")
       WebElement UpdateNomDetailAccountNumber;
   	
   	@FindBy(xpath="//select[@name='sourceFund']")
       WebElement UpdateNomDetailSourcFund;
   	
   	@FindBy(xpath="//input[@name='indicativeDeposite']")
       WebElement UpdateNomDetailIndicativeDepositAmount;
   	
   	@FindBy(xpath="//input[@value='New Hodge a/c']")
       WebElement UpdateNomDetailNewHodge;
   	
   	@FindBy(xpath="//input[@value='Nominated a/c']")
       WebElement UpdateNomDetailNominatedAccount;
   	
   	@FindBy(xpath="//button[@class='edit-nominee save-nominee']")
       WebElement UpdateNomDetailSave;
   	
   	@FindBy(xpath="//button[@class='edit-nominee cancel-nominee ']")
       WebElement UpdateNomDetailCancel;
    
 //ReviewInformation -ReviewInfo
    
    @FindBy(xpath="(//*[local-name()='svg'])[1]")
	WebElement ReviewInfoPersonalDetail;
	
	@FindBy(xpath="//ul/li[@class='list-value'][1]/div[2]")
	WebElement ReviewInfoTitle;
	
	@FindBy(xpath="//ul/li[@class='list-value'][2]/div[2]")
	WebElement ReviewInfoFirstName;
	
	@FindBy(xpath="//ul/li[@class='list-value'][3]/div[2]")
	WebElement ReviewInfoMiddleName;

	@FindBy(xpath="//ul/li[@class='list-value'][4]/div[2]")
	WebElement ReviewInfoLastName;
	
	@FindBy(xpath="//ul/li[@class='list-value'][5]/div[2]")
	WebElement ReviewInfoDOB;
	
	@FindBy(xpath="//ul/li[@class='list-value'][6]/div[2]")
	WebElement ReviewInfoNIN;
	
	@FindBy(xpath="//ul/li[@class='list-value'][7]/div[2]")
	WebElement ReviewInfoMobNo;
	
	@FindBy(xpath="//ul/li[@class='list-value'][8]/div[2]")
	WebElement ReviewInfoEmailAddress;
	
	//Review Additional Info-ReviewAddInfo

	@FindBy(xpath="//ul/li[@class='list-data'][1]/div[2]")
	WebElement ReviewInfoNationality;
	
	@FindBy(xpath="//ul/li[@class='list-data'][2]/div[2]")
	WebElement ReviewInfoHomeNo;
	
	@FindBy(xpath="//div[@class='addressAlign']")
	WebElement ReviewInfoResidentialAddress;
	
	@FindBy(xpath="//ul/li[@class='list-data'][3]/div[2]")
	WebElement ReviewInfoPostalCode;
	
	
	@FindBy(xpath="//ul/li[@class='list-data'][4]/div[2]")  //YY
	WebElement ReviewInfoCountryofResidence;
	
	@FindBy(xpath="//ul/li[@class='list-data'][5]/div[2]")
	WebElement ReviewInfoUSResident;
	
	@FindBy(xpath="//ul/li[@class='list-data'][6]/div[2]")
	WebElement ReviewInfoTaxIdentificationNumber;
	
	@FindBy(xpath="//ul/li[@class='list-data'][7]/div[2]")
	WebElement ReviewInfoMarketingPreference;
	
	@FindBy(xpath="//ul/li[@class='list-data'][8]/div[2]")
	WebElement ReviewInfoContactPreference;
	
	@FindBy(xpath="//ul/li[@class='item'][1]/div[2]")
	WebElement ReviewInfoAccountHolderName;
	
	@FindBy(xpath="//ul/li[@class='item'][2]/div[2]")
	WebElement ReviewInfoSortCode;
	
	@FindBy(xpath="//ul/li[@class='item'][3]/div[2]")
	WebElement ReviewInfoAccountNumber;
	
	@FindBy(xpath="//ul/li[@class='item'][4]/div[2]")
	WebElement ReviewInfoSourceOfFund;
	
	@FindBy(xpath="//ul/li[@class='item'][5]/div[2]")
	WebElement ReviewInfoIndicativeDepositAmount;
	
    @FindBy(xpath="//ul/li[@class='item'][6]/div[2]")
	WebElement ReviewInfoInterestPaymentPreference;
	
    @FindBy(xpath="//div[@class='reviewDetailsContainer']")
    List<WebElement>ReviewInfopersonal_additionalInfo;
    
    @FindBy(xpath="(//*[local-name()='svg'])[2]]")
    WebElement ReviewInfoNominateDdetail;
	
    @FindBy(xpath="//div[@class='review-info-wrapper']")
    List<WebElement>ReviewInfoNominatedInfo;
    
    //Checking conditions and submission of soleonboarding on Review Information page
    
    @FindBy(xpath="//input[@name='firstTerm']")
    WebElement ReviewInfoReadTermsConditions;
    
    @FindBy(xpath="(//a[@class='rules-btn'])[1]]")
    WebElement ReviewInfoReadTermsConditionslink;
    
    @FindBy(xpath="//input[@name='secondTerm']")
    WebElement ReviewInfoReadFSCSDoc;
    
    @FindBy(xpath="(//a[@class='rules-btn'])[2]]")
    WebElement ReviewInfoReadFSCSDoclink;
    
    @FindBy(xpath="//input[@name='thirdTerm']")
    WebElement ReviewInfoDeclareInfo;
    
    @FindBy(xpath="//input[@name='fourTerm']")
    WebElement ReviewInfoTicktoConfirm;
   
    @FindBy(xpath="//button[@class='edit-nominee save-nominee disabled']")
    WebElement ReviewInfoSubmit;
    
    @FindBy(xpath="//a[@class='exit-wrap']")
    WebElement ReviewInfoExit;
    
    @FindBy(xpath="//p[@class='thankyouMessage']")
    WebElement ReviewInfoSuccessfullSubmission;
    
  //******************************************Update Additional Info************************
    //Update AdditionalInfo
    // Review page Verification
	 String expText="Review Information";
	 
	 @FindBy(xpath="//*[@id=\"root\"]/div/div[2]/div/div[1]/div[1]/div[1]")
    WebElement reviewText;
	 // verifying Edit button
	 @FindBy(xpath="//p[text()='Personal Details ']")	
	  WebElement personlDetails;
	 @FindBy (xpath="//button[text()='Edit']")
	  WebElement PersonalInfoeditDetails; 
	 // User updates Nationality
	 @FindBy (xpath="//select[@name='nationality']")
	 WebElement nationality;
	 // User Updates Home Number
	 @FindBy(name="homeNumber")
	 WebElement personalInfohomeNumber;
	 // Residential Address	  
    @FindBy(xpath="//input[@class='rbt-input-main form-control rbt-input']")
    WebElement personalInfoResidentialAddress;
    // Us Resident update
    @FindBy(xpath="//*[@id=\"Ellipse_266\"]/circle[1]")
     WebElement usResidentUpdate ;  
    @FindBy(name="usCitizenTIN")
    WebElement taxIdentificationNumber;
    // Market Preference
    @FindBy(name="SMS")
    WebElement markeingPreferenceSMS;  
    @FindBy(name="Email")
    WebElement marketingPreferenceEmail;  
    // Contact Preference
    @FindBy(xpath="//input[@value='email']")
    WebElement contactPreferenceEmailUncheck;
    @FindBy(name="Telephone")
    WebElement contactPreferenceTelephone;
    // Save Button 
    @FindBy(xpath="//button[text()='Save']")
    WebElement additionalInfosave;

 //********************************** //action methods of marketing and contact preferences/communication channels on Additional Information page**************************************
    public void selectPreferences(String MarketingPrefernce,String ContactPreference)
    {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		
		if(AdditionalInfoSMSMarketPrefernce.isSelected()) 
		{
			AdditionalInfoSMSMarketPrefernce.click();
			
		}

		if(AdditionalInfoEmailMarketPrefernce.isSelected()) 
		{
			AdditionalInfoEmailMarketPrefernce.click();
			
		}
		if(AdditionalInfoNOMarketingUpdate.isSelected()) 
		{
			AdditionalInfoNOMarketingUpdate.click();
			
		}
		if(AdditionalInfoEmailContactPrefernce.isSelected()) 
		{
			AdditionalInfoEmailContactPrefernce.click();
			
		}
		
		if(AdditionalInfoTelephoneContactPrefernce.isSelected()) 
		{
			AdditionalInfoTelephoneContactPrefernce.click();
			
		}
		//Marketing Preference
	
		if(MarketingPrefernce.contains("SMS"))
		{
			AdditionalInfoSMSMarketPrefernce.click();
	
		}
		else if(MarketingPrefernce.contains("Email"))
		{
			AdditionalInfoEmailMarketPrefernce.click();
	
		}
		else if(MarketingPrefernce.contains("No marketing updates"))
		{
		    AdditionalInfoNOMarketingUpdate.click();
		}
		
		//Contact Preference 
		else if(ContactPreference.contains("Email"))
		{
			AdditionalInfoEmailContactPrefernce.click();
		}
		else if(ContactPreference.contains("Telephone"))
		{
			AdditionalInfoTelephoneContactPrefernce.click();
		}
		
		
	}
   
	    public void clickAdditionalInfoSaveAndProceed()
	    {
	    	AdditionalInfoSaveAndProceed.click();
	    }               
     
   	
   //******************Filling Nominated bank details action methods*************************************************
    
  	public void fillNominatedBankDetails(String AccountHolderName, String Sortcode1,String Sortcode2, String Sortcode3, String AccountNumber, String ReAccountNumber, String SourceFund, String IndicativeDepositAmount,String interestPaymentPreference)
   	{
		NomBankDetAccountholderName.sendKeys(AccountHolderName);
		NomBankDetSortCode1.sendKeys(Sortcode1);
    	NomBankDetSortCode1.sendKeys(Sortcode2);
    	NomBankDetSortCode1.sendKeys(Sortcode3);
    	NomBankDetAccountNumber.sendKeys(AccountNumber);
        NomBankDetReAccountNumber.sendKeys(ReAccountNumber);
  	  
        Select selectSrc=new Select(NomBankDetSourceFund);
		selectSrc.selectByVisibleText(SourceFund);;
	  
    	NomBankDetIndicativeDepositAmount.sendKeys(IndicativeDepositAmount);
   
   	    JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		
		
		if(interestPaymentPreference.equals("New Hodge a/c"))
		{
			NomBankDetNewHodgeAccount.click();
		}
		else if(interestPaymentPreference.equals("Nominated a/c"))
	    {
	    	NomBankDetNominatedAccount.click();
		}
		else 
		{
			System.out.println("Please select the interest Payment Preference");
		}
	}
    
    public void ClickSaveProceed()
    {
    	NomBankDetSave.click();
    }
    
    public void ClickCancel()
    {
    	NomBankDetCancel.click();
    }
    
    
//**************************Update Nomination Bank Detail action methods**************************************/
	
	public void clickNominatedBankDetails()
	{
		UpdateNomDetailNominatedAccount.click();
    }
	
	public void clickNominatedDetailEditBtn()
    {
		UpdateNomDetailEdit.click();
    } 
	
	public void editNominatedBankDetails(String AccountHolderName, String Sortcode,String AccountNumber,String SourceofFunds, String IndicativeDepositAmount, String InterestPaymentPreference)
	{
		UpdateNomDetailSortcode.clear();
		UpdateNomDetailAccountHoldername.sendKeys(AccountHolderName);
		
		UpdateNomDetailSortcode.clear();
    	UpdateNomDetailSortcode.sendKeys(Sortcode);
  	  
   
    	UpdateNomDetailAccountNumber.clear();
    	UpdateNomDetailAccountNumber.sendKeys(AccountNumber);
  	  
    	UpdateNomDetailAccountNumber.clear();
		Select selectSrc=new Select(UpdateNomDetailSourcFund);
		selectSrc.selectByVisibleText(SourceofFunds);
   
    	UpdateNomDetailIndicativeDepositAmount.sendKeys(IndicativeDepositAmount);
    
		if(InterestPaymentPreference.equals("New Hodge a/c"))
		{
			NomBankDetNewHodgeAccount.click();
		}
		else if(InterestPaymentPreference.equals("Nominated a/c"))
	    {
	    	NomBankDetNominatedAccount.click();
		}
		else 
		{
		}	System.out.println("Please select the interest Payment Preference");
		
	}
    
    public void clickSaveProceedBtn()
    {
    	UpdateNomDetailSave.click();
    }
	
    public void clickCancelBtn()
    {
    	UpdateNomDetailCancel.click();
    }
    

//**************************Review Information action methods*****************************************************/
   
 
    public void clickPersonalDetails()
    {
    	ReviewInfoPersonalDetail.click();
    }
   
    public void clickNominatedDetails()
    {
    	ReviewInfoNominateDdetail.click();
    }
   
	public String getTxtTitle()
	{
		return ReviewInfoTitle.getText();
	}

	public String getTxtFirstName() {
		return ReviewInfoFirstName.getText();
	}

	public String getTxtMiddleName() {
		return ReviewInfoMiddleName.getText();
	}

	public String getTxtLastName() {
		return ReviewInfoLastName.getText();
	}

	public String getTxtDOB() {
		return ReviewInfoDOB.getText();
	}

	public String getTxtNIN() {
		return ReviewInfoNIN.getText();
	}

	public String getTxtMobNo() {
		return ReviewInfoMobNo.getText();
	}

	public String getTxtEmailAddress() {
		return ReviewInfoEmailAddress.getText();
	}

	public String getTxtNationality() {
		return ReviewInfoNationality.getText();
	}

	public String getTxtHomeNo() {
		return ReviewInfoHomeNo.getText();
	}

	public String getTxtResidentialAddress() {
		return ReviewInfoResidentialAddress.getText();
	}

	public String getTxtPostalCode() {
		return ReviewInfoPostalCode.getText();
	}

	public String[][] getTxtCountryOnwards(String CountryofResidence ,String USResident)
	{
		String[][] countryonwards=new String[5][2];
		
		if(CountryofResidence.equals("UK")&&USResident.equals("No"))
		{
				countryonwards[0][0]="US Resident";
				countryonwards[1][0]="Marketing Preferences";
				countryonwards[2][0]="Contact Preferences";
				countryonwards[0][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][4]/div[2]")).getText();
				countryonwards[1][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][5]/div[2]")).getText();
				countryonwards[2][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][6]/div[2]")).getText();
	
				return countryonwards;
			
		}
		
		else if(CountryofResidence.equals("UK")&&USResident.equals("Yes"))
		{
			
				
				countryonwards[0][0]="US Resident";
				countryonwards[1][0]="Tax Identification Number";
				countryonwards[2][0]="Marketing Preferences";
				countryonwards[3][0]="Contact Preferences";
			
				countryonwards[0][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][4]/div[2]")).getText();
				countryonwards[1][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][5]/div[2]")).getText();
				countryonwards[2][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][6]/div[2]")).getText();
				countryonwards[3][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][7]/div[2]")).getText();
	
				return countryonwards;
			
		}	
		
		else if(!CountryofResidence.equals("UK")&&USResident.equals("Yes"))
		{
			
				countryonwards[0][0]="Country of Residence";
				countryonwards[1][0]="US Resident";
				countryonwards[2][0]="Tax Identification Number";
				countryonwards[3][0]="Marketing Preferences";
				countryonwards[4][0]="Contact Preferences";
			
				countryonwards[0][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][4]/div[2]")).getText();
				countryonwards[1][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][5]/div[2]")).getText();
				countryonwards[2][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][6]/div[2]")).getText();
				countryonwards[3][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][7]/div[2]")).getText();
				countryonwards[4][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][8]/div[2]")).getText();
				
				return countryonwards;
			
		}	
	
		else if(!CountryofResidence.equals("UK")&&USResident.equals("No"))
		{
			
				countryonwards[0][0]="Country of Residence";
				countryonwards[1][0]="US Resident";
				countryonwards[2][0]="Marketing Preferences";
				countryonwards[3][0]="Contact Preferences";
			
			
				countryonwards[0][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][4]/div[2]")).getText();
				countryonwards[1][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][5]/div[2]")).getText();
				countryonwards[2][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][6]/div[2]")).getText();
				countryonwards[3][1]=driver.findElement(By.xpath("//ul/li[@class='list-data'][7]/div[2]")).getText();
	
				return countryonwards;
			
		}	
	 return countryonwards;
		
	
	}
	
	public String getTxtAccountHolderName() {
		return ReviewInfoAccountHolderName.getText();
	}

	public String getTxtSortCode() {
		return ReviewInfoSortCode.getText();
	}

	public String gettxtAccountNumber() {
		return ReviewInfoAccountNumber.getText();
	}

	public String getTxtSourcOfFund() {
		return ReviewInfoSourceOfFund.getText();
	}

	public String getTxtIndicativeDepositAmount() {
		return ReviewInfoIndicativeDepositAmount.getText();
	}

	public String getTxtInterestPaymentPreference()
	{
		return ReviewInfoInterestPaymentPreference.getText();
	}

//*************Successfull Submission Of Registration of Soleonboarding Journey******************
	
		public void checkConditions()
		{
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
			
			if(ReviewInfoReadTermsConditions.isSelected()) 
			{
				ReviewInfoReadTermsConditions.click();
				
			}
			if(ReviewInfoReadFSCSDoc.isSelected()) 
			{
				ReviewInfoReadFSCSDoc.click();
				
			}
			if(ReviewInfoDeclareInfo.isSelected()) 
			{
				ReviewInfoDeclareInfo.click();
				
			}
			if(ReviewInfoTicktoConfirm.isSelected()) 
			{
				ReviewInfoTicktoConfirm.click();
				
			}
			
			ReviewInfoReadTermsConditions.click();
			ReviewInfoReadFSCSDoc.click();
			ReviewInfoDeclareInfo.click();
			ReviewInfoTicktoConfirm.click();
		}
		
		public void clickSubmitBtn() 
		{
		
			if(ReviewInfoSubmit.isEnabled())
			{
			 ReviewInfoSubmit.click();
			}
	    }
		
	    public void clickExitBtn()
	    {
	    	ReviewInfoExit.click();
	    }
	    
	    public String getSuccessfullSubmission()
	    {
	         String msg =ReviewInfoSuccessfullSubmission.getText();
	         return msg;
	    }
  
//**************************Update Additional Info action methods**************************************/
		
	  //AdditionalInfoedit
		 public String personalInfoReviewPage()  {
		    	String actText=reviewText.getText();
		    	if(expText==actText) {	
		    	}
				return actText;
		    }
		    public void personalInfoEditButton() {	
		    	PersonalInfoeditDetails.click();
		    	//scroll upto edit button
		    	je=(JavascriptExecutor)driver;
		    	je.executeScript("arugument[0].scrollIntoView", PersonalInfoeditDetails);
		    	PersonalInfoeditDetails.click();
		    }
		    public void additionalDetailUpdate(String Nationality,String HomeNumber,String residentialAddress, String TIN) { 
		    	nationality.sendKeys(Nationality);
		    	action=new Actions(driver);
		    	action.sendKeys(Keys.ARROW_DOWN).perform();
		    	action.sendKeys(Keys.ENTER).perform();
		    // PersonalInfoHomenumber
		    	personalInfohomeNumber.sendKeys(HomeNumber);
		    // PersonalInfoResidential
		    	personalInfoResidentialAddress.click();
		    	action =new Actions(driver);
		    	action.moveToElement(personalInfoResidentialAddress);
		    	action.keyDown(Keys.CONTROL).sendKeys("a","backspace");
		    	action.keyUp(Keys.CONTROL);
		    	personalInfoResidentialAddress.sendKeys(residentialAddress);
		    	action.sendKeys(Keys.ARROW_DOWN).perform();
		    	action.sendKeys(Keys.ENTER).perform();	
		  
		    // TaxIdentificationNumber
		    	usResidentUpdate.click();
		    	taxIdentificationNumber.sendKeys(TIN);	
		    // userUpdatesMarketingPreferences
		    	if(markeingPreferenceSMS.isSelected()) 
		    		 marketingPreferenceEmail.click();
		    // contactPreferenceTelephone	
		    	if(!contactPreferenceTelephone.isSelected()) {
		    	contactPreferenceEmailUncheck.click();// To uncheck the selected option
		    	contactPreferenceTelephone.click();
		    	}
		    }
		    public void personalInfoSave() {	
		    	additionalInfosave.click();
		    }
//**********************************************************************************************************	


	public void IconfirmCheckbox() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		BefApplyIconfirmCheckBox.click();
	}

	public void confirmAndProceed() {
		if(BefApplyIconfirmCheckBox.isSelected()) {
			BefApplyconfirmAndProceed.click();
			System.out.println("Checkbox is checked");
		}else {
			System.out.println("Please select the I consent Checkbox");
		}
	}
	
	public void applicationAlert(){
		
	}

	public void fillPersonalDetails(String prefix, String FirstName,String MiddleName, String LastName, String DD, String MM, String YYYY, String NIN1,String NIN2, String NIN3, String NIN4,String NIN5) {
		Select select  = new Select(persDetPrefix);
		select.selectByVisibleText(prefix);

		persDetFirstName.sendKeys(FirstName);
		persDetFirstName.sendKeys(MiddleName);
		persDetFirstName.sendKeys(LastName);

		Select select1  = new Select(persDetPrefix);
		select1.selectByValue(DD);
		select1.selectByValue(MM);
		select1.selectByValue(YYYY);



	}


}
