package stepDefinitions;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.bouncycastle.util.test.TestRandomData;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.Pagebjects_SoleOnboardingJourney;
import util.ExcelReader;
import util.SeleniumDriver;


public class Steps_SoleOnboardingJourney 
{
	private Pagebjects_SoleOnboardingJourney pagebjects_Sole = new Pagebjects_SoleOnboardingJourney(SeleniumDriver.getDriver());
	
	
	@Given("^User opens the browser and launches the web URL$")
    public void user_opens_the_browser_and_launches_the_web_url() throws Throwable {
		SeleniumDriver.getDriver().get("https://d24k3akkz9t4ai.cloudfront.net/");
    }


    @When("^user clicks on the checkbox with text For tax purposes I am a UK Resident$")
    public void user_clicks_on_the_checkbox_with_text_for_tax_purposes_i_am_a_uk_resident() throws Throwable {
    	pagebjects_Sole.IconfirmCheckbox();
        
    }

    @Then("^user clicks on \"([^\"]*)\" button$")
    public void user_clicks_on_something_button(String strArg1) throws Throwable {
    	pagebjects_Sole.confirmAndProceed();
        
    }
    
    @And("^Popup opens with Is this Joint application with Yes and No buttons$")
    public void popup_opens_with_is_this_joint_application_with_yes_and_no_buttons() throws Throwable {
        
    }

    @Then("^User clicks on \"([^\"]*)\" button on the popup$")
    public void user_clicks_on_something_button_on_the_popup(String strArg1) throws Throwable {
        
    }

    @Then("^Registration Process for Sole Onboarding page loads$")
    public void registration_process_for_sole_onboarding_page_loads() throws Throwable {
        throw new PendingException();
    }

//*********************Filling Personal Details Registration ************************************
    
    @Given("^the user navigates to personal details page in sole onboarding process$")
    public void the_user_navigates_to_personal_details_page_in_sole_onboarding_process() throws Throwable {
        throw new PendingException();
    }

    @When("^user fills the personal details from given \"([^\"]*)\" and rownumber (.+)$")
    public void user_fills_the_personal_details_from_given_something_and_rownumber(String sheetname, int rownumber, String strArg1) throws Throwable {
    	
    	ExcelReader reader = new ExcelReader();
		List<Map<String,String>> testData =reader.getData(".\\src\\test\\resources\\Data\\SoleonboardingData1.xls", sheetname);
		
		String Prefix = testData.get(rownumber).get("Prefix");
		String FirstName = testData.get(rownumber).get("FirstName");
		String MiddleName = testData.get(rownumber).get("MiddleName");
		String LastName = testData.get(rownumber).get("LastName");
		String DD = testData.get(rownumber).get("DD");
		String MM = testData.get(rownumber).get("MM");
		String YYYY = testData.get(rownumber).get("YYYY");
		String NIN1 = testData.get(rownumber).get("NIN1");
		String NIN2 = testData.get(rownumber).get("NIN2");
		String NIN3 = testData.get(rownumber).get("NIN3");
		String NIN4 = testData.get(rownumber).get("NIN4");
		String NIN5 = testData.get(rownumber).get("NIN5");
		
		
		pagebjects_Sole.fillPersonalDetails(Prefix, FirstName, MiddleName, LastName, DD, MM,YYYY, NIN1, NIN2, NIN3, NIN4, NIN5);

    }

    @Then("^User clicks on Save & Proceed button$")
    public void user_clicks_on_save_proceed_button() throws Throwable
    {
    	pagebjects_Sole.saveAndProceedPersonalDetail();
    }

    @Then("^Confirm Details Popup with confirm button$")
    public void confirm_details_popup_with_confirm_button() throws Throwable {
        
    }

    @Then("^User clicks on Confirm button in the Popup$")
    public void user_clicks_on_confirm_button_in_the_popup() throws Throwable 
    {
    	pagebjects_Sole.confirmAndProceed2();
    }
    
    //****************************Successful Customer Registration - Sole Onboarding**********************
    @Given("^User navigates to Registration process successfully popup in Sole Onboarding$")
    public void user_navigates_to_registration_process_successfully_popup_in_sole_onboarding() throws Throwable {
        
    }

    @When("^User can see entered username from given \"([^\"]*)\" and rownumber (.+)$")
    public void user_can_see_entered_username_from_given_something_and_rownumber(String sheetname,int rownumber) throws Throwable 
    {
        
    	
    	ExcelReader reader = new ExcelReader();
		List<Map<String,String>> testData =reader.getData(".\\src\\test\\resources\\Data\\SoleonboardingData1.xls", sheetname);
	
		String expectedUsername = testData.get(rownumber).get("FirstName");
		
		 String actualUsername = pagebjects_Sole.verifyUsername();
	  		
	  		if(actualUsername.contains(expectedUsername))
	  		{
	  			Assert.assertTrue(true);
	  		}
	  		else 
	  		{
	  			Assert.assertTrue(false);
	  		}
    	
    }

    @Then("^user clicks Proceed to Application button$")
    public void user_clicks_proceed_to_application_button() throws Throwable 
    {
    	pagebjects_Sole.ProceedToApplication();
    }

    
    
  //***************************Marketing And Contact Preferences/Communication channels on Additional Details***************************** 
   
    @Given("^User navigates to additonal information page in sole onboarding process with the title \"([^\"]*)\"$")
    public void user_navigates_to_additonal_information_page_in_sole_onboarding_process_with_the_title_something(String expTitle) 
    {

    	
    	 String actualTitle = SeleniumDriver.getDriver().getTitle();
  		
  		if(actualTitle.equals(expTitle))
  		{
  			Assert.assertTrue(true);
  		}
  		else 
  		{
  			Assert.assertTrue(false);
  		}

    }
    
    @When("^user clicks on marketing preferences and contact preferences on additional information page from given \"([^\"]*)\" and rownumber (.+)$")
    public void user_clicks_on_marketing_preferences_on_additional_information_page_from_given_something_and_rownumber(String sheetname, int rownumber) throws Throwable 
    {
    	ExcelReader reader = new ExcelReader();
		List<Map<String,String>> testData =reader.getData(".\\src\\test\\resources\\Data\\SoleonboardingData1.xls", sheetname);
		
		String MarketingPreference= testData.get(rownumber).get("MarketingPreferences");
		String ContactPreference= testData.get(rownumber).get("ContactPreferences");
	
		pagebjects_Sole.selectPreferences(MarketingPreference,ContactPreference);

    }
    @Then("^User clicks on Save & Proceed button on additional information page$")
    public void user_clicks_on_save_proceed_button_on_additional_information_page() throws Throwable
    {
    	
    	pagebjects_Sole.clickAdditionalInfoSaveAndProceed();
    	
    	
    }

  
 //*************Filling Nomination Bank Details************************************************************************
    
    
    @Given("^User navigates to nominated bank details page in sole onboarding process with the title \"([^\"]*)\"$")
    public void User_navigates_to_nominated_bank_details_page_in_sole_onboarding_process_with_the_title(String expTitle) 
    {
	   
	   String actualTitle = SeleniumDriver.getDriver().getTitle();
		
		if(actualTitle.equals(expTitle))
		{
			Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
        
    }

    @When("^User fills the nominated bank details from given \"([^\"]*)\" and rownumber (.+)$")
    public void User_fills_the_nominated_bank_details_from_given_something_and_rownumber(String sheetname, int rownumber) throws Throwable, IOException
    {
    	
    	ExcelReader reader = new ExcelReader();
		List<Map<String,String>> testData =reader.getData(".\\src\\test\\resources\\Data\\SoleonboardingData1.xls", sheetname);
		
	    String AccountHolderName = testData.get(rownumber).get("AccountHolderName");
		String Sortcode1=testData.get(rownumber).get("SortCode1");
	    String Sortcode2 = testData.get(rownumber).get("SortCode2");
		String Sortcode3 = testData.get(rownumber).get("SortCode3");
		String AccountNumber = testData.get(rownumber).get("AccountNumber");
		String ReAccountNumber = testData.get(rownumber).get("ReEnterAccountNumber");
		String SourceofFunds = testData.get(rownumber).get("SourceofFunds");
		String IndicativeDepositAmount = testData.get(rownumber).get("IndicativeDepositAmount");
		String InterestPaymentPreference = testData.get(rownumber).get("InterestPaymentPreference");

		
		pagebjects_Sole.fillNominatedBankDetails(AccountHolderName, Sortcode1, Sortcode2, Sortcode3, AccountNumber, ReAccountNumber, SourceofFunds, IndicativeDepositAmount, InterestPaymentPreference);
	}

    @Then("^User clicks on Save & Proceed button on nominated bank details page$")
    public void User_clicks_on_save_proceed_button_on_nominated_bank_details_page() 
    {
    	pagebjects_Sole.ClickSaveProceed();
    }
    
    

  //********************************Update Additional Info***************************

  //AdditionalInfoEdit

  @When("^User should view review page$")
  public void user_should_view_review_page()  {
  	 
   }
   
   @When("^User cliks on edit button to update additional information$")
   public void user_cliks_on_edit_button_to_update_additional_information() {
  	 
  	 pagebjects_Sole.personalInfoEditButton();
   }
   
   @And("^ User updates Nationality as \"([^\"]*)\" and rownumber (.+)$")
      public void user_updates_nationality_as_something_and_rownumber(String sheetname,int rownumber) throws Throwable {
     
  	 ExcelReader reader = new ExcelReader();
  		List<Map<String,String>> testData = 
  				reader.getData(".\\src\\test\\resources\\Data\\SoleonboardingData1.xls", sheetname);
  		
  		String national = testData.get(0).get("Nationality");
  		String hmNumber = testData.get(1).get("HomeNumber");
  		String resAdd = testData.get(2).get("residentialAddress");
  		String tin = testData.get(3).get("TIN");
  	 
  		pagebjects_Sole.additionalDetailUpdate(national, hmNumber, resAdd, tin); 

      }

   @Then("^Click on Save button$")
      public void click_on_save_button() {
  	 pagebjects_Sole.personalInfoSave();
      }


  //*************Updating Nomination Bank Details*********************************************************
   
    @Given("^User navigates to review information page in sole onboarding process$")
    public void User_navigates_to_review_information_page_in_sole_onboarding_process() 
    {
    	
        
    }
    
    @When("^User clicks on nominated bank details$")
    public void user_clicks_on_nominated_bank_details() 
    {
    	pagebjects_Sole.clickNominatedBankDetails();
    }
    
    @And("^User click on edit button$")
    public void user_click_on_edit_button() 
    {
    	pagebjects_Sole.clickNominatedDetailEditBtn();
    }
    
    
    @And("^User edit the nominated bank details from given \"([^\"]*)\" and rownumber (.+)$")
    public void user_edit_the_nominated_bank_details_from_given_something_and_rownumber(String sheetname, int rownumber) throws Throwable 
   {  
    	ExcelReader reader = new ExcelReader();
		List<Map<String,String>> testData =reader.getData(".\\src\\test\\resources\\Data\\SoleonboardingData1.xls", sheetname);
	
	    String AccountHolderName = testData.get(rownumber).get("AccountHolderName");
		String Sortcode=testData.get(rownumber).get("SortCode");
	    String AccountNumber = testData.get(rownumber).get("AccountNumber");
		String SourceofFunds = testData.get(rownumber).get("SourceofFunds");
		String IndicativeDepositAmount = testData.get(rownumber).get("IndicativeDepositAmount");
		String InterestPaymentPreference = testData.get(rownumber).get("InterestPaymentPreference");

		pagebjects_Sole.editNominatedBankDetails(AccountHolderName, Sortcode, AccountNumber,SourceofFunds, IndicativeDepositAmount, InterestPaymentPreference);
	
   }
    
    @Then("^clicks on Save button$")
    public void clicks_on_save_button() throws Throwable 
    {
    	pagebjects_Sole.clickSaveProceedBtn();
    }

    
 //*************Review Personal and Additional Information*********************************************************
   
    @Given("^User navigates to review information page with the title \"([^\"]*)\" to review personal info$")
    public void user_navigates_to_review_information_page_with_the_title_something_to_review_personal_info(String expTitle)  
    {
    	 
		   String actualTitle = SeleniumDriver.getDriver().getTitle();
			
			if(actualTitle.equals(expTitle))
			{
				Assert.assertTrue(true);
			}
			else 
			{
				Assert.assertTrue(false);
			}
        
    }

    @When("^User clicks on personal details to review entered information$")
    public void user_clicks_on_personal_details_to_review_entered_information() 
    {
    	 pagebjects_Sole.clickPersonalDetails();
    }

    @And("^User can view all the entered personal details and additional information from given \"([^\"]*)\" and rownumber (.+)$")
    public void user_can_view_all_the_entered_personal_details_and_additional_information_from_given_something_and_rownumber(String sheetname, int rownumber) throws Throwable 
    {

    	ExcelReader reader = new ExcelReader();
		List<Map<String,String>> testData =reader.getData(".\\src\\test\\resources\\Data\\SoleonboardingData1.xls", sheetname);
	
	    String Title = testData.get(rownumber).get("Prefix");
		String FirstName=testData.get(rownumber).get("FirstName");
	    String MiddleName = testData.get(rownumber).get("MiddleName");
		String LastName = testData.get(rownumber).get("SourceofFunds");
		String DD = testData.get(rownumber).get("DD");
		String MM = testData.get(rownumber).get("MM");
		String YYYY = testData.get(rownumber).get("YYYY");
		String NIN1 = testData.get(rownumber).get("NIN1");
		String NIN2 = testData.get(rownumber).get("NIN2");
		String NIN3 = testData.get(rownumber).get("NIN3");
		String NIN4 = testData.get(rownumber).get("NIN4");
		String NIN5 = testData.get(rownumber).get("NIN5");
		String MobileNumber = testData.get(rownumber).get("MobileNumber");
		String EmailAddress = testData.get(rownumber).get("EmailAddress");
		String Nationality = testData.get(rownumber).get("Nationality");
		String HomeNumber = testData.get(rownumber).get("HomeNumber");
		String ResidentialAddress = testData.get(rownumber).get("ResidentialAddress");
		String PostalCode = testData.get(rownumber).get("PostalCode");
		String CountryOfResidence = testData.get(rownumber).get("CountryOfResidence");
		String USResident = testData.get(rownumber).get("USResident");
		String TaxIndentificationNumber = testData.get(rownumber).get("TaxIndentificationNumber");
		String MarketingPreference = testData.get(rownumber).get("MarketingPreference");
		String ContactPreference = testData.get(rownumber).get("ContactPreference");
		
		String NationalInsuranceNumber=NIN1+"-"+NIN2+"-"+NIN3+"-"+NIN4+"-"+NIN5;
		String DOB=DD+"-"+MM+"-"+YYYY;
	 
		 if(pagebjects_Sole.getTxtTitle().equals(Title))
		   {
			   Assert.assertTrue(true);
		   }
	
		   if(pagebjects_Sole.getTxtFirstName().equals(FirstName))
		   {
			   Assert.assertTrue(true);
		   }
			  
		   if(pagebjects_Sole.getTxtMiddleName().equals(MiddleName))
		   {
			   Assert.assertTrue(true);
		   }
			
		   if(pagebjects_Sole.getTxtLastName().equals(LastName))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(pagebjects_Sole.getTxtDOB().equals(DOB))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(pagebjects_Sole.getTxtNIN().equals(NationalInsuranceNumber))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(pagebjects_Sole.getTxtMobNo().equals(MobileNumber))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(pagebjects_Sole.getTxtEmailAddress().equals(EmailAddress))
		   {
			   Assert.assertTrue(true);
		   }
		   if(pagebjects_Sole.getTxtNationality().equals(Nationality))
		   {
			   Assert.assertTrue(true);
		   }
		   if(pagebjects_Sole.getTxtHomeNo().equals(HomeNumber ))
		   {
			   Assert.assertTrue(true);
		   }
		   if(pagebjects_Sole.getTxtResidentialAddress().equals(ResidentialAddress))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(pagebjects_Sole.getTxtPostalCode().equals(PostalCode))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   //As xpath is geting changed depending on value of fields CountryOfResidence and USResident 
		   String[][] countryonwards=pagebjects_Sole.getTxtCountryOnwards(CountryOfResidence, USResident);
		   
		   for(int i=0;i<5;i++)
		   {
			   for(int j=0;j<2;j++)
			   {
				   String attribute=countryonwards[i][j];
				   j++;
				   if(attribute.equals("US Resident")) 
				   {
					 
					   if(countryonwards[i][j].equals(USResident))
					   {
						   Assert.assertTrue(true);
					   }   
				   }
				   
				   else if(attribute.equals("Country of Residence")) 
				   {
					   
					   if(countryonwards[i][j].equals(CountryOfResidence))
					   {
						   Assert.assertTrue(true);
					   }   
				   }
				   
				   else if(attribute.equals("Tax Identification Number")) 
				   {
					   String[] taxno=countryonwards[i][j].split("-");
					   String tax="";
					   for(String s:taxno)
					   {
						   tax=tax+s;
						   
					   }
					   
					   if(tax.equals(TaxIndentificationNumber))
					   {
						   Assert.assertTrue(true);
					   }   
				   }

				   else if(attribute.equals("Marketing Preferences")) 
				   {
					   
					   if(countryonwards[i][j].equals(MarketingPreference))
					   {
						   Assert.assertTrue(true);
					   }   
				   }
				   else if(attribute.equals("Contact Preferences")) 
				   {
					   
					   if(countryonwards[i][j].equals(ContactPreference))
					   {
						   Assert.assertTrue(true);
					   }   
				   }
				   
				   
			   }
			   
			   
		   }
	
    }

    
    
    //*************Review Nominated Information*********************************************************

   @Given("^User navigates to review information page with the title \"([^\"]*)\" to review nominated bank details$")
    public void user_navigates_to_review_information_page_with_the_title_something_to_review_nominated_bank_details(String expTitle) throws Throwable 
    {
    	  String actualTitle = SeleniumDriver.getDriver().getTitle();
			
			if(actualTitle.equals(expTitle))
			{
				Assert.assertTrue(true);
			}
			else 
			{
				Assert.assertTrue(false);
			}
    }
    
    @When("^User clicks on nominated bank details to review entered information$")
    public void user_clicks_on_nominated_bank_details_to_review_entered_information() throws Throwable
    {
    	 pagebjects_Sole.clickNominatedDetails();
    }

    @And("^User can view all the entered nominated bank details from given \"([^\"]*)\" and rownumber (.+)$")
    public void user_can_view_all_the_entered_nominated_bank_details_from_given_something_and_rownumber(String sheetname, int rownumber) throws Throwable 
    {
     	ExcelReader reader = new ExcelReader();
		List<Map<String,String>> testData =reader.getData(".\\Data\\SoleonboardingData1.xls", sheetname);
	
		    String AccountHolderName = testData.get(rownumber).get("AccountHolderName");
			String Sortcode1=testData.get(rownumber).get("SortCode1");
		    String Sortcode2 = testData.get(rownumber).get("SortCode2");
			String Sortcode3 = testData.get(rownumber).get("SortCode3");
			String AccountNumber = testData.get(rownumber).get("AccountNumber");
			String ReAccountNumber = testData.get(rownumber).get("ReEnterAccountNumber");
			String SourceofFunds = testData.get(rownumber).get("SourceofFunds");
			String IndicativeDepositAmount = testData.get(rownumber).get("IndicativeDepositAmount");
			String InterestPaymentPreference = testData.get(rownumber).get("InterestPaymentPreference");

			String SortCode=Sortcode1+"-"+Sortcode2+"-"+Sortcode3;
		  
		if(pagebjects_Sole.getTxtAccountHolderName().equals(AccountHolderName))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(pagebjects_Sole.getTxtSortCode().equals(SortCode))
		   {
			   Assert.assertTrue(true);
		   }
		 
		   if(pagebjects_Sole.gettxtAccountNumber().equals(AccountNumber))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(pagebjects_Sole.getTxtSourcOfFund().equals(ReAccountNumber))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(pagebjects_Sole.getTxtIndicativeDepositAmount().equals(SourceofFunds))
		   {
			   Assert.assertTrue(true);
		   }
		   
		   if(pagebjects_Sole.getTxtInterestPaymentPreference().equals(IndicativeDepositAmount))
		   {
			   Assert.assertTrue(true);
		   }

		   
		   if(pagebjects_Sole.getTxtInterestPaymentPreference().equals(InterestPaymentPreference))
		   {
			   Assert.assertTrue(true);
		   }
    }
    
    
  //*************Successfull Submission Of Soleonboarding Journey*********************************************************


    @Given("^User can view review information page with the title \"([^\"]*)\" to submit application$")
    public void user_can_view_review_information_page_with_the_title_something_to_submit_application(String expTitle)
    {

    	  String actualTitle = SeleniumDriver.getDriver().getTitle();
			
			if(actualTitle.equals(expTitle))
			{
				Assert.assertTrue(true);
			}
			else 
			{
				Assert.assertTrue(false);
			}
    	
    }
    
    @When("^User clicks on checkbox provided for accepting the given consents$")
    public void user_clicks_on_checkbox_provided_for_accepting_the_given_consents() throws Throwable 
    {
    	pagebjects_Sole.checkConditions();
    
    }

    @And("^User clicks on submit button$")
    public void user_clicks_on_submit_button()
    {
    	pagebjects_Sole.clickSubmitBtn();

    }
    @Then("^Application submitted successfully$")
    public void application_submitted_successfully()  
    {

    	if(pagebjects_Sole.getSuccessfullSubmission().equals("Thank you for sending us your application."))
    	{
    		Assert.assertTrue(true);
		}
		else 
		{
			Assert.assertTrue(false);
		}
	
    }

}

   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

	
	   

	
	 


	
    
    
    
    
    
    
