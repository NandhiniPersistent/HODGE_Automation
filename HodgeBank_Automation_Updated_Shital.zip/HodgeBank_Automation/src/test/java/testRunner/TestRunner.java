package testRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		publish = true,
		features = ".//src/test/resources/features/TS001_SoleOnboardingJourney.feature",
		glue={"stepDefinitions","appHooks"},
		//dryRun=false,
		//stepNotifications=true,
		monochrome=true,
		plugin= {"pretty","html:target/cucumber.html"})
		//"json:target/JSON_Reports/report.json"})
		//tags="@SoleOnboarding")
	//"html:target/cucumber.html"
//"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",

public class TestRunner {

}
