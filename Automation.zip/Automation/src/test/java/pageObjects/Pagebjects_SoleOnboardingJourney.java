package pageObjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;


public class Pagebjects_SoleOnboardingJourney {


	Pagebjects_SoleOnboardingJourney pageObjSole = null;
	WebDriver driver = null;

	/******Constructor of the Page objects class for Sole Onboarding******/

	public Pagebjects_SoleOnboardingJourney(WebDriver driver) {
		this.driver=driver;

	}

	//Before you Apply - BefApply
	@FindBy(xpath = "/html[1]/body[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[10]/div[1]/*[name()='svg'][1]")
	WebElement BefApplyIconfirmCheckBox;

	@FindBy(xpath = "//button[text()='Confirm & Proceed']")
	WebElement BefApplyconfirmAndProceed;

	//Personal Details page - PersDet
	@FindBy(xpath = "//div[text()='Select Prefix']")
	WebElement persDetPrefix;

	@FindBy(xpath = "//div[text()='First Name*']")
	WebElement persDetFirstName;

	@FindBy(xpath = "//div[text()='Middle Name']")
	WebElement persDetMiddleName;

	@FindBy(xpath = "//div[text()='Last Name*']")
	WebElement persDetLastName;

	@FindBy(xpath = "//input[contains(@placeholder,'DD')]")
	WebElement persDetDD;

	@FindBy(xpath = "//input[contains(@placeholder,'MM')]")
	WebElement persDetMM;

	@FindBy(xpath = "//input[contains(@placeholder,'YYYY')]")
	WebElement persDetYYYY;

	//National Identification Number - NIN
	@FindBy(xpath = "//input[contains(@placeholder,'QQ')]")
	WebElement persDetNIN1;

	@FindBy(xpath = "//input[contains(@placeholder,'12')]")
	WebElement persDetNIN2;

	@FindBy(xpath = "//input[contains(@placeholder,'34')]")
	WebElement persDetNIN3;

	@FindBy(xpath = "//input[contains(@placeholder,'56')]")
	WebElement persDetNIN4;

	@FindBy(xpath = "//input[contains(@placeholder,'C')]")
	WebElement persDetNIN5;

	@FindBy(css = ".customLoginBtn.ceraProMedium.btnMarginTop")
	WebElement persDetSaveAndProceed;
//******************************************************************************************************//	
	//Nominated Bank Details - NomBankDet
    @FindBy(xpath="(//input[@type='text'])[1]")
    WebElement NomBankDetAccountholderName;
    
    @FindBy(xpath="(//input[@type='text'])[2]")
	  WebElement ipTxtSortCode1;
	  
    @FindBy(xpath="(//input[@type='text'])[3]")
	  WebElement ipTxtSortCode2;
    
    @FindBy(xpath="(//input[@type='text'])[4]")
	  WebElement ipTxtSortCode3;
    
    @FindBy(xpath="(//input[@type='text'])[5]")
    WebElement ipTxtAccountNumber;	  
    
    @FindBy(xpath="(//input[@type='text'])[6]")
    WebElement ipTxtReAccountNumber;
    
    @FindBy(xpath="//select[@class='inputBoxDropdown']")
    WebElement ipTxtSourceFund;
    
    @FindBy(xpath="(//input[@type='text'])[7]")
    WebElement ipTxtIndicativeDepositAmount;
  
    @FindBy(xpath="(//span[@class='checkmark'])[1]")
    WebElement chkBoxNewHodgeAccount;
    
    @FindBy(xpath="(//span[@class='checkmark'])[2]")
    WebElement chkBoxNominatedAccount;
    
    @FindBy(xpath="//button[contains(text(),'Save & Proceed')]")
    WebElement btnSave;
   
    @FindBy(xpath="//button[@class='edit-nominee cancel-nominee ']")
    WebElement btnCancel;



	public void IconfirmCheckbox() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		BefApplyIconfirmCheckBox.click();
	}

	public void confirmAndProceed() {
		if(BefApplyIconfirmCheckBox.isSelected()) {
			BefApplyconfirmAndProceed.click();
			System.out.println("Checkbox is checked");
		}else {
			System.out.println("Please select the I consent Checkbox");
		}
	}
	
	public void applicationAlert(){
		
	}

	public void fillPersonalDetails(String prefix, String FirstName,String MiddleName, String LastName, String DD, String MM, String YYYY, String NIN1,String NIN2, String NIN3, String NIN4,String NIN5) {
		Select select  = new Select(persDetPrefix);
		select.selectByVisibleText(prefix);

		persDetFirstName.sendKeys(FirstName);
		persDetFirstName.sendKeys(MiddleName);
		persDetFirstName.sendKeys(LastName);

		Select select1  = new Select(persDetPrefix);
		select1.selectByValue(DD);
		select1.selectByValue(MM);
		select1.selectByValue(YYYY);



	}


}
