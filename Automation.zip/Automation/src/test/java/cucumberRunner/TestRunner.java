package cucumberRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
		publish = true,
		features = "src/test/resources/features",
		glue="stepDefinitions",
		//dryRun=false,
		stepNotifications=true,
		monochrome=true,
		plugin= {"pretty","json:target/JSON_Reports/report.json"})
		//tags="@SoleOnboarding")
	//"html:target/cucumber.html"

public class TestRunner {

}
