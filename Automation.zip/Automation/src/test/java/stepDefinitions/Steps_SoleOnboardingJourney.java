package stepDefinitions;

import java.util.List;
import java.util.Map;

import io.cucumber.java.PendingException;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.Pagebjects_SoleOnboardingJourney;
import util.ExcelReader;
import util.SeleniumDriver;


public class Steps_SoleOnboardingJourney {
	private Pagebjects_SoleOnboardingJourney pagebjects_Sole = new Pagebjects_SoleOnboardingJourney(SeleniumDriver.getDriver());
	
	
	@Given("^User opens the browser and launches the web URL$")
    public void user_opens_the_browser_and_launches_the_web_url() throws Throwable {
		SeleniumDriver.getDriver().get("https://d24k3akkz9t4ai.cloudfront.net/");
    }


    @When("^user clicks on the checkbox with text For tax purposes I am a UK Resident$")
    public void user_clicks_on_the_checkbox_with_text_for_tax_purposes_i_am_a_uk_resident() throws Throwable {
    	pagebjects_Sole.IconfirmCheckbox();
        
    }

    @Then("^user clicks on \"([^\"]*)\" button$")
    public void user_clicks_on_something_button(String strArg1) throws Throwable {
    	pagebjects_Sole.confirmAndProceed();
        
    }
    
    @And("^Popup opens with Is this Joint application with Yes and No buttons$")
    public void popup_opens_with_is_this_joint_application_with_yes_and_no_buttons() throws Throwable {
        
    }

    @Then("^User clicks on \"([^\"]*)\" button on the popup$")
    public void user_clicks_on_something_button_on_the_popup(String strArg1) throws Throwable {
        
    }

    @Then("^Registration Process for Sole Onboarding page loads$")
    public void registration_process_for_sole_onboarding_page_loads() throws Throwable {
        throw new PendingException();
    }

//
    
    @Given("^the user navigates to personal details page in sole onboarding process$")
    public void the_user_navigates_to_personal_details_page_in_sole_onboarding_process() throws Throwable {
        throw new PendingException();
    }

    @When("^user fills the personal details from given \"([^\"]*)\" and rownumber (.+)$")
    public void user_fills_the_personal_details_from_given_something_and_rownumber(String sheetname, int rownumber, String strArg1) throws Throwable {
    	ExcelReader reader = new ExcelReader();
		List<Map<String,String>> testData = 
				reader.getData("/Users/nandhini/Desktop/automation.xlsx", sheetname);
		
		String heading = testData.get(rownumber).get("subjectheading");
		String email = testData.get(rownumber).get("email");
		String orderRef = testData.get(rownumber).get("orderref");
		String message = testData.get(rownumber).get("message");
		
		pagebjects_Sole.fillPersonalDetails(message, message, message, sheetname, message, message, sheetname, strArg1, heading, email, orderRef, message);

    }

    @Then("^User clicks on Save & Proceed button$")
    public void user_clicks_on_save_proceed_button() throws Throwable {
        throw new PendingException();
    }

    @Then("^Confirm Details Popup with confirm button$")
    public void confirm_details_popup_with_confirm_button() throws Throwable {
        throw new PendingException();
    }

    @Then("^User clicks on Confirm button in the Popup$")
    public void user_clicks_on_confirm_button_in_the_popup() throws Throwable {
        throw new PendingException();
    }


}
