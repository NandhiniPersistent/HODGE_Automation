package util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class SeleniumDriver {
	private static 	SeleniumDriver seleniumDriver;
	
	public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();
	
	//Initialize WebDriver
	
	private static WebDriver driver;
	private static WebDriverWait wait;
	public final static int Duration=40;
	public final static int PAGE_LOAD_TIMEOUT=50;
	
	public WebDriver init_driver(String browser) {

		System.out.println("browser value is: " + browser);

		if (browser.equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			tlDriver.set(new ChromeDriver());
		} else if (browser.equals("firefox")) {
			WebDriverManager.firefoxdriver().setup();
			tlDriver.set(new FirefoxDriver());
		} else {
			System.out.println("Please pass the correct browser value: " + browser);
		}

		getDriver().manage().deleteAllCookies();
		getDriver().manage().window().maximize();
		return getDriver();

	}
	
	public static void openPage(String url) {
		driver.get(url);
		
	}	
	
	public static WebDriver getDriver() {
		return driver;
	}
	
    public static void setUpDriver() {
    	if(seleniumDriver==null) {
    		seleniumDriver=new SeleniumDriver();
    		
    	}
    }
    public static void tearDown() {
    	if(driver!=null) {
    		driver.close();
    		driver.quit();
    	}
    	seleniumDriver=null;
    }
}
